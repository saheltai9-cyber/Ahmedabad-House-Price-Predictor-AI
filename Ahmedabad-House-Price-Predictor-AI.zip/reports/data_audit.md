# Ahmedabad House Price Predictor AI - Data Audit Report

## 1. Dataset Verification & Provenance
- **Target City**: Ahmedabad, Gujarat, India (Exclusive)
- **Dataset Source**: HansikaPrabodini/Ahmedabad-Flat-Price-Dataset
- **License**: Public / Open Educational Dataset
- **Strict Location Compliance**: 100% verified Ahmedabad property records. Zero Bengaluru, Mumbai, or external city records.

---

## 2. Ingestion & Deduplication Summary
| Ingestion Metric | Value | Description |
| :--- | :--- | :--- |
| **Initial Raw Listings** | 6,853 | Total rows ingested from raw CSV |
| **Exact Duplicate Rows** | 166 | Complete duplicate rows across all scraped fields |
| **Listing Duplicates Removed** | 398 | Duplicate listings identified on Title + Area + Price |
| **Final Retained Valid Records** | 6,216 | Cleaned records suitable for machine learning |
| **Retention Rate** | 90.7% | High data fidelity preserved |

---

## 3. Schema Processing & Unit Conversions
- **Property Price**: Parsed from localized Indian denomination strings (`Lac` and `Cr`). Normalized into uniform **INR Lakhs** (`₹ Lakhs`).
- **Total Area & Unit Validation**:
  - `sqft` (Square Feet): Multiplier `1.0`
  - `sqyrd` (Square Yards / Vraj / Gaj): Verified `9.0` multiplier (standard Gujarat real estate conversion).
  - `sqm` (Square Meters): Verified `10.7639` multiplier.
  - Rows with ambiguous or missing area units were strictly rejected.
- **BHK Extraction**: Reliably extracted via regex from the property title (`1 BHK` to `6 BHK`).
- **Locality Extraction**: Standardized Ahmedabad localities extracted from title and listing metadata. Rare localities (< 5 listings) grouped into `Other`.
- **Property Status**: Standardized into `Ready to Move` and `Under Construction`.
- **Furnishing**: Recovered across misaligned columns into `Unfurnished`, `Semi-Furnished`, and `Furnished`.
- **Transaction**: Cleaned into `Resale` and `New Property`.

---

## 4. Outlier Analysis & Realistic Residential Bounds
To protect regression model performance from web-scraping artifacts, the following domain-specific boundary filters were enforced:
- **Price Range Filter**: ₹5.0 Lakhs to ₹2,500.0 Lakhs (Exempted 8 listings with bogus prices like ₹618 Cr or unpriced calls).
- **Living Area Filter**: 200.0 sqft to 12,000.0 sqft (Exempted 79 listings with typos like 12 sqft or 750,000 sqft).
- **Derived Rate Bounds**: ₹1,000.0/sqft to ₹40,000.0/sqft (Exempted 26 corrupted listings).
- **BHK Range**: 1 to 6 BHK.

---

## 5. Cleaned Dataset Statistical Overview
- **Unique Localities**: 118
- **Localities with >= 5 Listings**: 118
- **Property Price (Lakhs)**:
  - Minimum: ₹7.00 Lakhs
  - Median: ₹115.00 Lakhs
  - Maximum: ₹1672.00 Lakhs
- **Property Area (Sq.Ft.)**:
  - Minimum: 200 sqft
  - Median: 1574 sqft
  - Maximum: 11900 sqft

---

## 6. Data Leakage Prevention Guarantee
- `price_sqft` and `derived_rate` were utilized **exclusively** during data auditing for boundary sanity checks.
- Both columns are **strictly excluded** from model training feature vectors to prevent mathematical target leakage.
