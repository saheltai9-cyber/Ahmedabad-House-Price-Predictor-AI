"""
Main Machine Learning training pipeline script for Ahmedabad House Price Predictor AI.
Orchestrates data ingestion, cleaning, auditing, EDA chart generation, CV model selection,
final test evaluation, and model serialization.
"""
import sys
import logging
from pathlib import Path

# Ensure root directory is in sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config import settings
from src.data_loader import download_dataset, load_raw_dataset, inspect_raw_schema
from src.preprocessing import clean_dataset, generate_data_audit_report
from src.visualization import generate_all_eda_figures
from src.model_training import train_and_evaluate, save_model_artifacts

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("TrainPipeline")

def run_pipeline(force_download: bool = False) -> None:
    """
    Executes the complete end-to-end Machine Learning pipeline.
    """
    print("\n" + "=" * 70)
    print(" AHMEDABAD HOUSE PRICE PREDICTOR AI - MACHINE LEARNING PIPELINE")
    print("=" * 70 + "\n")

    # Step 1: Initialize directories
    logger.info("Step 1/6: Initializing project directories...")
    settings.init_directories()

    # Step 2: Download raw dataset if missing
    logger.info("Step 2/6: Checking and downloading Ahmedabad dataset...")
    raw_path = download_dataset(force=force_download)
    df_raw = load_raw_dataset(raw_path)
    schema_info = inspect_raw_schema(df_raw)
    logger.info(f"Raw records loaded: {schema_info['row_count']:,} rows, {schema_info['column_count']} columns.")

    # Step 3: Data Cleaning & Preprocessing
    logger.info("Step 3/6: Cleaning data, removing duplicates & auditing outliers...")
    df_clean, audit_metrics = clean_dataset(df_raw)
    df_clean.to_csv(settings.PROCESSED_DATA_PATH, index=False)
    logger.info(f"Cleaned dataset saved to: {settings.PROCESSED_DATA_PATH}")

    # Generate Data Audit Report
    generate_data_audit_report(audit_metrics, settings.DATA_AUDIT_PATH)
    logger.info(f"Data audit report saved to: {settings.DATA_AUDIT_PATH}")

    # Step 4: Exploratory Data Analysis & Visualization
    logger.info("Step 4/6: Generating exploratory data analysis charts...")
    generate_all_eda_figures(df_raw, df_clean, settings.FIGURES_DIR)
    logger.info(f"All EDA figures successfully saved to: {settings.FIGURES_DIR}")

    # Step 5: Model Training, Cross-Validation & Selection
    logger.info("Step 5/6: Training models, comparing CV metrics & evaluating on test set...")
    pipeline, artifacts = train_and_evaluate(
        df_clean,
        test_size=settings.TEST_SPLIT_RATIO,
        random_state=settings.RANDOM_SEED
    )

    # Step 6: Artifact Serialization
    logger.info("Step 6/6: Serializing pipeline and saving metadata/metrics...")
    save_model_artifacts(pipeline, artifacts)

    print("\n" + "=" * 70)
    print(" TRAINING PIPELINE COMPLETED SUCCESSFULLY!")
    print("=" * 70)
    print(f" Best Selected Model: {artifacts['best_model_name']}")
    print(f" Training Samples:    {artifacts['train_samples']:,}")
    print(f" Held-Out Test Set:   {artifacts['test_samples']:,} (20% split)")
    print("-" * 70)
    print(f" Test Set MAE:        ₹ {artifacts['test_metrics']['mae_lakhs']:.2f} Lakhs")
    print(f" Test Set RMSE:       ₹ {artifacts['test_metrics']['rmse_lakhs']:.2f} Lakhs")
    print(f" Test Set R² Score:   {artifacts['test_metrics']['r2_score']:.4f}")
    print("-" * 70)
    print(f" Saved Model Pipeline: {settings.MODEL_PATH}")
    print(f" Saved Model Metadata: {settings.METADATA_PATH}")
    print(f" Saved Metrics Report: {settings.METRICS_PATH}")
    print("=" * 70 + "\n")

if __name__ == "__main__":
    force = "--force" in sys.argv
    run_pipeline(force_download=force)

