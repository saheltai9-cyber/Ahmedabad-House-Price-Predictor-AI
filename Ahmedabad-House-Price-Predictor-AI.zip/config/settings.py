"""
Configuration and constants for Ahmedabad House Price Predictor AI.
Ensures reproducible data pipeline, robust paths, and model hyperparameters.
"""
from pathlib import Path

# Base directories
BASE_DIR = Path(__file__).resolve().parent.parent

# Data paths
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

RAW_DATA_PATH = RAW_DATA_DIR / "ahmedabad.csv"
PROCESSED_DATA_PATH = PROCESSED_DATA_DIR / "ahmedabad_cleaned.csv"

# Model paths
MODELS_DIR = BASE_DIR / "models"
MODEL_PATH = MODELS_DIR / "ahmedabad_house_price_model.joblib"
METADATA_PATH = MODELS_DIR / "model_metadata.json"

# Reports and figures
REPORTS_DIR = BASE_DIR / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
DATA_AUDIT_PATH = REPORTS_DIR / "data_audit.md"
METRICS_PATH = REPORTS_DIR / "model_metrics.json"

# Static assets and images
ASSETS_DIR = BASE_DIR / "assets"
IMAGES_DIR = ASSETS_DIR / "images"

# Dataset Source & License info
DATASET_URL = "https://raw.githubusercontent.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset/main/ahmedabad.csv"
DATASET_REPO = "https://github.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset"
DATASET_LICENSE = "Public / Open Educational Dataset"
DATASET_DESCRIPTION = "Residential property listings scraped specifically for Ahmedabad, Gujarat, India."

# Model settings
RANDOM_SEED = 42
TEST_SPLIT_RATIO = 0.20
CV_FOLDS = 5

# Realistic Residential Domain Bounds for Ahmedabad (Outlier Filtering & Validation)
MIN_PRICE_LAKHS = 5.0      # Minimum realistic residential apartment price (₹ 5 Lakhs)
MAX_PRICE_LAKHS = 2500.0   # Maximum realistic residential apartment price (₹ 25 Crores)
MIN_AREA_SQFT = 200.0      # Minimum realistic living area (200 sqft)
MAX_AREA_SQFT = 12000.0    # Maximum realistic residential flat / penthouse area (12,000 sqft)
MIN_RATE_RS_SQFT = 1000.0  # Minimum realistic rate per sqft in Ahmedabad (₹ 1,000)
MAX_RATE_RS_SQFT = 40000.0 # Maximum realistic rate per sqft for luxury properties (₹ 40,000)
MIN_BHK = 1
MAX_BHK = 6

# Feature names
NUMERICAL_FEATURES = ["total_sqft", "bhk"]
CATEGORICAL_FEATURES = ["locality", "type_area", "status", "furnishing", "transaction"]
TARGET_FEATURE = "price_lakhs"

# Target derived leakage columns that MUST be strictly excluded from model features
LEAKAGE_COLUMNS = ["price", "price_sqft", "derived_rate", "rate"]

# Ensure directories exist
def init_directories():
    for d in [RAW_DATA_DIR, PROCESSED_DATA_DIR, MODELS_DIR, FIGURES_DIR, IMAGES_DIR]:
        d.mkdir(parents=True, exist_ok=True)

if __name__ == "__main__":
    init_directories()
    print("Project directories initialized successfully.")

