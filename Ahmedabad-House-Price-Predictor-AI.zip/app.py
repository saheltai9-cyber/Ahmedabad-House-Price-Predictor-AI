"""
Ahmedabad House Price Predictor AI - Premium Streamlit Web Application
A professional real-estate valuation & intelligence platform tailored exclusively for Ahmedabad, Gujarat.
Redesigned with executive SaaS UI/UX, interactive Plotly graphics, verified local assets, and complete error-handling.
"""
import sys
import json
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from PIL import Image

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from config import settings
from src.prediction import (
    AhmedabadPricePredictor,
    format_denomination,
    format_inr_rupees,
    calculate_emi
)

# Page configuration
st.set_page_config(
    page_title="Ahmedabad House Price Predictor AI",
    page_icon="🏢",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Design System Colors
# Primary Navy: #142A43 | Secondary Teal: #158A83 | Background: #F7F8FA
# Card Background: #FFFFFF | Text Primary: #202B38 | Text Secondary: #718096 | Accent: #EBA45B
CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #202B38;
    }

    .stApp {
        background-color: #F7F8FA;
    }

    /* Container padding */
    .block-container {
        padding-top: 1.2rem;
        padding-bottom: 3rem;
        max-width: 1320px;
    }

    /* Top Navigation Header Area */
    .top-header-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 0.85rem 1.4rem;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 6px rgba(20, 42, 67, 0.03);
    }
    .top-breadcrumbs {
        font-size: 0.85rem;
        font-weight: 600;
        color: #718096;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .top-breadcrumb-active {
        color: #142A43;
        font-weight: 700;
    }
    .top-location-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        background: #E8F5F4;
        color: #158A83;
        font-size: 0.78rem;
        font-weight: 700;
        padding: 0.3rem 0.75rem;
        border-radius: 20px;
        border: 1px solid #C2E7E5;
        letter-spacing: 0.2px;
    }

    /* Sidebar Brand Styling */
    .sidebar-brand-box {
        display: flex;
        align-items: center;
        gap: 0.85rem;
        padding: 0.5rem 0.2rem 1.2rem 0.2rem;
        border-bottom: 1px solid #E2E8F0;
        margin-bottom: 1.2rem;
    }
    .sidebar-brand-name {
        font-size: 1.05rem;
        font-weight: 800;
        color: #142A43;
        line-height: 1.25;
        margin: 0;
    }
    .sidebar-brand-tagline {
        font-size: 0.72rem;
        color: #718096;
        margin: 0;
        font-weight: 500;
    }

    /* Sidebar Footer Info Card */
    .sidebar-footer-card {
        background: #F8FAFC;
        border: 1px solid #E2E8F0;
        border-radius: 10px;
        padding: 0.85rem;
        font-size: 0.78rem;
        margin-top: 1.5rem;
    }
    .sidebar-status-indicator {
        display: inline-block;
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #10B981;
        margin-right: 0.4rem;
    }

    /* Hero Section Card */
    .hero-card {
        background: linear-gradient(135deg, #142A43 0%, #1A365D 60%, #1E3D60 100%);
        border-radius: 16px;
        padding: 2.6rem;
        color: #FFFFFF;
        box-shadow: 0 12px 30px rgba(20, 42, 67, 0.12);
        margin-bottom: 2rem;
        position: relative;
    }
    .hero-badge-pill {
        display: inline-block;
        background: rgba(235, 164, 91, 0.2);
        color: #EBA45B;
        border: 1px solid rgba(235, 164, 91, 0.4);
        padding: 0.25rem 0.7rem;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-bottom: 0.85rem;
    }
    .hero-headline {
        font-size: 2.35rem;
        font-weight: 800;
        line-height: 1.2;
        color: #FFFFFF;
        margin-bottom: 0.75rem;
        letter-spacing: -0.5px;
    }
    .hero-subtext {
        font-size: 1.05rem;
        color: #E2E8F0;
        margin-bottom: 1.75rem;
        max-width: 680px;
        line-height: 1.55;
    }
    .hero-stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
        gap: 1rem;
        padding-top: 1.5rem;
        border-top: 1px solid rgba(255, 255, 255, 0.15);
    }
    .hero-stat-box {
        background: rgba(255, 255, 255, 0.08);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 8px;
        padding: 0.65rem 0.9rem;
    }
    .hero-stat-value {
        font-size: 1.3rem;
        font-weight: 800;
        color: #EBA45B;
    }
    .hero-stat-label {
        font-size: 0.72rem;
        color: #E2E8F0;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        font-weight: 600;
    }

    /* Metric KPI Cards */
    .kpi-card {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 1.25rem 1.4rem;
        box-shadow: 0 2px 8px rgba(20, 42, 67, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(20, 42, 67, 0.07);
        border-color: #CBD5E1;
    }
    .kpi-label {
        color: #718096;
        font-size: 0.78rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .kpi-value {
        color: #142A43;
        font-size: 1.65rem;
        font-weight: 800;
        margin-top: 0.35rem;
        line-height: 1.2;
    }
    .kpi-sub {
        color: #94A3B8;
        font-size: 0.78rem;
        margin-top: 0.25rem;
        font-weight: 500;
    }

    /* Valuation Result Card */
    .result-container-card {
        background: #FFFFFF;
        border: 2px solid #158A83;
        border-radius: 16px;
        padding: 2rem;
        box-shadow: 0 10px 25px rgba(21, 138, 131, 0.08);
        margin-top: 1.5rem;
    }
    .result-badge-pill {
        background: #E8F5F4;
        color: #158A83;
        font-size: 0.78rem;
        font-weight: 700;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        display: inline-block;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.6rem;
    }
    .result-main-price {
        font-size: 2.85rem;
        font-weight: 800;
        color: #142A43;
        line-height: 1.1;
    }
    .result-exact-rupees {
        font-size: 1.35rem;
        font-weight: 700;
        color: #158A83;
        margin-top: 0.35rem;
    }
    .result-margin-box {
        background: #F8FAFC;
        border-left: 4px solid #EBA45B;
        border-radius: 0 8px 8px 0;
        padding: 0.85rem 1.15rem;
        margin: 1.25rem 0;
        font-size: 0.95rem;
        color: #334155;
    }
    .property-pill-tag {
        display: inline-block;
        background: #F1F5F9;
        color: #142A43;
        border: 1px solid #E2E8F0;
        padding: 0.35rem 0.75rem;
        border-radius: 6px;
        font-size: 0.82rem;
        font-weight: 600;
        margin-right: 0.45rem;
        margin-bottom: 0.45rem;
    }

    /* Disclaimer Card */
    .disclaimer-card {
        background: #FFFBEB;
        border: 1px solid #FDE68A;
        border-radius: 8px;
        padding: 0.85rem 1.15rem;
        color: #92400E;
        font-size: 0.82rem;
        line-height: 1.45;
        margin-top: 1.25rem;
    }

    /* Sidebar Radio Navigation Override */
    div[data-testid="stSidebar"] div[role="radiogroup"] > label {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 8px;
        padding: 0.65rem 1rem;
        margin-bottom: 0.45rem;
        transition: all 0.2s ease;
        cursor: pointer;
    }
    div[data-testid="stSidebar"] div[role="radiogroup"] > label:hover {
        background: #F8FAFC;
        border-color: #CBD5E1;
    }

    /* Buttons */
    .stButton > button {
        border-radius: 8px;
        font-weight: 700;
        letter-spacing: 0.2px;
        transition: all 0.2s ease;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# Helper function to safely render local image assets
def render_safe_image(
    image_filename: str,
    caption: Optional[str] = None,
    alt_text: str = "Ahmedabad Residential Property"
) -> bool:
    """
    Renders an image from the local assets/images directory safely.
    Guarantees no broken image icons by falling back to styled HTML placeholder if missing.
    """
    img_path = settings.IMAGES_DIR / image_filename
    if img_path.exists():
        try:
            with Image.open(img_path) as img:
                st.image(img, caption=caption, use_container_width=True)
                return True
        except Exception as e:
            logging.error(f"Failed to open local image {img_path}: {e}")

    # Visual fallback card if image is unavailable
    st.markdown(
        f"""
        <div style="background: #EEF4F8; border: 1px dashed #CBD5E1; border-radius: 12px; padding: 2rem; text-align: center; color: #718096;">
            <div style="font-size: 2rem; margin-bottom: 0.5rem;">🏙️</div>
            <div style="font-weight: 700; color: #142A43;">{alt_text}</div>
            <div style="font-size: 0.8rem; margin-top: 0.25rem;">Ahmedabad, Gujarat, India</div>
        </div>
        """,
        unsafe_allow_html=True
    )
    return False

@st.cache_resource
def get_predictor():
    """Initializes and caches the trained prediction engine."""
    if not settings.MODEL_PATH.exists():
        return None
    try:
        return AhmedabadPricePredictor(
            model_path=settings.MODEL_PATH,
            metadata_path=settings.METADATA_PATH
        )
    except Exception as e:
        logging.error(f"Error loading model: {e}")
        return None

@st.cache_data
def load_clean_data():
    """Loads cleaned dataset for visualizations and statistics."""
    if settings.PROCESSED_DATA_PATH.exists():
        return pd.read_csv(settings.PROCESSED_DATA_PATH)
    return None

@st.cache_data
def load_metrics_report():
    """Loads model evaluation report metrics."""
    if settings.METRICS_PATH.exists():
        with open(settings.METRICS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return None

def main():
    predictor = get_predictor()
    df_clean = load_clean_data()
    metrics_report = load_metrics_report()

    # Session State for navigation tracking
    if "current_page" not in st.session_state:
        st.session_state["current_page"] = "Overview"

    # SIDEBAR: Complete Redesign with Brand Mark & Footer
    with st.sidebar:
        # Brand Mark Header
        logo_path = settings.IMAGES_DIR / "logo.png"
        col_logo, col_brand = st.columns([0.3, 0.7], gap="small")
        with col_logo:
            if logo_path.exists():
                with Image.open(logo_path) as logo_img:
                    st.image(logo_img, width=48)
            else:
                st.markdown("<div style='font-size: 2rem;'>🏢</div>", unsafe_allow_html=True)
        with col_brand:
            st.markdown("""
            <div style="line-height: 1.2; padding-top: 2px;">
                <span style="font-size: 0.95rem; font-weight: 800; color: #142A43; display: block;">Ahmedabad AI</span>
                <span style="font-size: 0.72rem; color: #718096; font-weight: 600;">House Price Predictor</span>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("<hr style='margin: 0.8rem 0 1.2rem 0; border: none; border-top: 1px solid #E2E8F0;'>", unsafe_allow_html=True)

        # Verified Local Architectural Card
        render_safe_image(
            "ahmedabad_architecture.jpg",
            caption="Ahmedabad Architecture",
            alt_text="Ahmedabad Residential Architecture"
        )

        st.markdown("<p style='font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: #718096; letter-spacing: 0.5px; margin-bottom: 0.4rem;'>Main Navigation</p>", unsafe_allow_html=True)

        # Navigation Menu Items (Consistent naming required in Part 2)
        nav_options = [
            "📊 Overview",
            "🔮 Price Predictor",
            "📈 Analytics",
            "ℹ️ About Project"
        ]

        # Sync radio with session state
        nav_index = 0
        if st.session_state["current_page"] == "Price Predictor":
            nav_index = 1
        elif st.session_state["current_page"] == "Analytics":
            nav_index = 2
        elif st.session_state["current_page"] == "About Project":
            nav_index = 3

        selected_nav = st.radio(
            "Navigation Menu",
            options=nav_options,
            index=nav_index,
            label_visibility="collapsed"
        )

        # Update current page
        clean_nav_name = selected_nav.split(" ", 1)[1]
        st.session_state["current_page"] = clean_nav_name

        # Professional Sidebar Footer
        st.markdown("<hr style='margin: 1.5rem 0 1rem 0; border: none; border-top: 1px solid #E2E8F0;'>", unsafe_allow_html=True)
        
        # Real Model Status Indicator
        model_name = metrics_report.get("model_name", "Random Forest") if metrics_report else "Random Forest"
        test_r2_val = metrics_report.get("test_metrics", {}).get("r2_score", 0.9138) if metrics_report else 0.914
        test_mae_val = metrics_report.get("test_metrics", {}).get("mae_lakhs", 30.01) if metrics_report else 30.01

        st.markdown(f"""
        <div class="sidebar-footer-card">
            <div style="font-weight: 700; color: #142A43; margin-bottom: 0.35rem; display: flex; align-items: center;">
                <span class="sidebar-status-indicator"></span> ML Model Active
            </div>
            <div style="color: #475569; font-size: 0.75rem;">
                <strong>Engine:</strong> {model_name}<br>
                <strong>Held-Out Test R²:</strong> {test_r2_val:.3f}<br>
                <strong>Held-Out Test MAE:</strong> ± ₹{test_mae_val:.1f} Lakhs
            </div>
            <div style="margin-top: 0.6rem; padding-top: 0.5rem; border-top: 1px solid #E2E8F0; color: #64748B; font-size: 0.72rem;">
                📍 <strong>Location:</strong> Ahmedabad, Gujarat<br>
                📊 <strong>Dataset Scope:</strong> 6,216 Validated Listings
            </div>
        </div>
        """, unsafe_allow_html=True)

    # TOP COMPLEMENTARY NAVBAR AREA
    st.markdown(f"""
    <div class="top-header-bar">
        <div class="top-breadcrumbs">
            <span>Ahmedabad AI Real Estate</span>
            <span>&rsaquo;</span>
            <span class="top-breadcrumb-active">{st.session_state['current_page']}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <span class="top-location-badge">📍 Ahmedabad, Gujarat (Strict Scope)</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # VIEW ROUTING
    if st.session_state["current_page"] == "Overview":
        render_overview_view(df_clean, metrics_report)
    elif st.session_state["current_page"] == "Price Predictor":
        render_predictor_view(predictor, df_clean)
    elif st.session_state["current_page"] == "Analytics":
        render_analytics_view(df_clean, metrics_report)
    elif st.session_state["current_page"] == "About Project":
        render_about_view(metrics_report)

def render_overview_view(df_clean, metrics_report):
    # HERO SECTION
    col_hero_content, col_hero_visual = st.columns([1.35, 0.85], gap="large")

    total_listings = f"{len(df_clean):,}" if df_clean is not None else "6,216"
    localities_count = f"{df_clean['locality'].nunique()}" if df_clean is not None else "118"
    test_r2_disp = f"{metrics_report.get('test_metrics', {}).get('r2_score', 0.9138):.3f}" if metrics_report else "0.914"
    test_mae_disp = f"₹ {metrics_report.get('test_metrics', {}).get('mae_lakhs', 30.01):.1f} L" if metrics_report else "₹ 30.0 L"

    with col_hero_content:
        st.markdown(f"""
        <div class="hero-card">
            <span class="hero-badge-pill">PRECISION REAL ESTATE VALUATION AI</span>
            <h1 class="hero-headline">Find Your Home's Estimated Value in Ahmedabad</h1>
            <p class="hero-subtext">Explore property prices and estimate residential values using Machine Learning calibrated strictly on verified Ahmedabad transaction records.</p>
            <div class="hero-stats-grid">
                <div class="hero-stat-box">
                    <div class="hero-stat-value">{total_listings}</div>
                    <div class="hero-stat-label">Verified Listings</div>
                </div>
                <div class="hero-stat-box">
                    <div class="hero-stat-value">{localities_count}</div>
                    <div class="hero-stat-label">Covered Localities</div>
                </div>
                <div class="hero-stat-box">
                    <div class="hero-stat-value">{test_r2_disp}</div>
                    <div class="hero-stat-label">Held-Out Test R²</div>
                </div>
                <div class="hero-stat-box">
                    <div class="hero-stat-value">{test_mae_disp}</div>
                    <div class="hero-stat-label">Test Set MAE</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        # Primary Call to Action Button navigating to Predictor
        if st.button("🔮 Estimate Property Price Now", type="primary", use_container_width=True):
            st.session_state["current_page"] = "Price Predictor"
            st.rerun()

    with col_hero_visual:
        render_safe_image(
            "hero_skyline.jpg",
            caption="Modern Residential Skyline, Ahmedabad",
            alt_text="Ahmedabad Residential Skyline"
        )

    st.markdown("<br>", unsafe_allow_html=True)

    # High-Level KPI Summary Cards
    kpi1, kpi2, kpi3, kpi4 = st.columns(4)

    med_price = f"₹ {df_clean['price_lakhs'].median():.1f} Lakhs" if df_clean is not None else "₹ 115.0 Lakhs"
    med_area = f"{int(df_clean['total_sqft'].median()):,} sq.ft" if df_clean is not None else "1,574 sq.ft"
    best_algo = metrics_report.get("model_name", "Random Forest") if metrics_report else "Random Forest"

    with kpi1:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">City Median Price</div>
            <div class="kpi-value">{med_price}</div>
            <div class="kpi-sub">Across all residential units</div>
        </div>
        """, unsafe_allow_html=True)

    with kpi2:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Median Living Area</div>
            <div class="kpi-value">{med_area}</div>
            <div class="kpi-sub">Standardized floor space</div>
        </div>
        """, unsafe_allow_html=True)

    with kpi3:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Algorithm Engine</div>
            <div class="kpi-value" style="font-size: 1.35rem; padding-top: 0.25rem;">{best_algo}</div>
            <div class="kpi-sub">5-Fold Cross-Validated</div>
        </div>
        """, unsafe_allow_html=True)

    with kpi4:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">Prime Sectors</div>
            <div class="kpi-value">Shela, Ambli, Bodakdev</div>
            <div class="kpi-sub">+115 residential localities</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Core Features & Architecture Highlights
    feat_left, feat_right = st.columns([1.15, 0.85], gap="large")

    with feat_left:
        st.markdown("### 🏆 Professional Features Built for Ahmedabad")
        st.markdown(r"""
        - **Authentic Localized Data**: Built strictly on genuine property records from Ahmedabad, Gujarat (Shela, Bodakdev, Bopal, Thaltej, Satellite, SG Highway, Vaishnodevi Circle, Gota, Chandkheda, and more).
        - **Gujarat-Specific Unit Handling**: Correctly identifies and converts local real estate land units like **Square Yards (`sqyrd` / Gaj / Vraj)** using the exact `9.0` sq.ft multiplier, and **Square Meters (`sqm`)** using `10.7639` sq.ft.
        - **Data Leakage Immunity**: Price per square foot (`price_sqft`) and target-derived rates are strictly quarantined to data auditing and excluded from model inputs.
        - **Transparent Valuation**: Every prediction provides empirical confidence error intervals ($\pm \text{MAE}$) and rate per sq.ft calculations.
        """)

    with feat_right:
        render_safe_image(
            "ahmedabad_landmark.jpg",
            caption="Urban Development & Living in Ahmedabad",
            alt_text="Ahmedabad Waterfront and Architecture"
        )

    # Interactive Market Distribution Preview
    if df_clean is not None:
        st.markdown("---")
        st.markdown("### 📈 Live Market Intelligence Preview")
        p_col1, p_col2 = st.columns(2, gap="medium")

        with p_col1:
            # Interactive Plotly Price Distribution
            fig_p = px.histogram(
                df_clean,
                x="price_lakhs",
                nbins=40,
                color_discrete_sequence=["#142A43"],
                title="Property Price Distribution (INR Lakhs)",
                labels={"price_lakhs": "Price (₹ in Lakhs)"}
            )
            fig_p.add_vline(x=df_clean["price_lakhs"].median(), line_dash="dash", line_color="#EBA45B", annotation_text=f"Median: ₹{df_clean['price_lakhs'].median():.1f}L")
            fig_p.update_layout(
                paper_bgcolor="#FFFFFF",
                plot_bgcolor="#F8FAFC",
                margin=dict(l=20, r=20, t=40, b=20),
                font=dict(family="Plus Jakarta Sans", color="#202B38")
            )
            st.plotly_chart(fig_p, use_container_width=True)

        with p_col2:
            # Interactive Top 10 Localities Bar Chart
            top10_locs = df_clean[df_clean["locality"] != "Other"]["locality"].value_counts().head(10).index
            df_top10 = df_clean[df_clean["locality"].isin(top10_locs)]
            med_by_loc = df_top10.groupby("locality")["price_lakhs"].median().sort_values(ascending=True).reset_index()
            
            fig_l = px.bar(
                med_by_loc,
                x="price_lakhs",
                y="locality",
                orientation="h",
                color="price_lakhs",
                color_continuous_scale=["#158A83", "#142A43"],
                title="Top 10 Localities by Median Price (₹ Lakhs)",
                labels={"price_lakhs": "Median Price (₹ Lakhs)", "locality": "Locality"}
            )
            fig_l.update_layout(
                paper_bgcolor="#FFFFFF",
                plot_bgcolor="#F8FAFC",
                coloraxis_showscale=False,
                margin=dict(l=20, r=20, t=40, b=20),
                font=dict(family="Plus Jakarta Sans", color="#202B38")
            )
            st.plotly_chart(fig_l, use_container_width=True)

def render_predictor_view(predictor, df_clean):
    st.markdown("## 🔮 Residential Property Price Predictor")
    st.markdown("Enter verified property characteristics to generate an algorithmic market valuation calibrated on historical Ahmedabad listings.")

    if predictor is None:
        st.error("⚠️ Trained model artifact not found at `models/ahmedabad_house_price_model.joblib`. Please run `python train.py` first.")
        return

    available_localities = predictor.get_supported_localities()
    if not available_localities and df_clean is not None:
        available_localities = sorted([str(loc) for loc in df_clean["locality"].unique() if loc != "Other"])
        available_localities.append("Other")

    # Form card wrapper
    with st.container():
        st.markdown("""
        <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 14px; padding: 1.5rem 1.8rem; box-shadow: 0 4px 12px rgba(20, 42, 67, 0.04); margin-bottom: 1.5rem;">
            <h4 style="color: #142A43; margin-top: 0; margin-bottom: 0.3rem;">Property Specifications</h4>
            <p style="color: #718096; font-size: 0.85rem; margin-bottom: 1.2rem;">All fields strictly correspond to validated Ahmedabad residential records.</p>
        </div>
        """, unsafe_allow_html=True)

        with st.form("property_valuation_form"):
            form_c1, form_c2 = st.columns(2, gap="medium")

            with form_c1:
                locality = st.selectbox(
                    "Ahmedabad Locality *",
                    options=available_localities,
                    index=available_localities.index("Shela") if "Shela" in available_localities else 0,
                    help="Select from 118 verified Ahmedabad residential localities."
                )

                bhk = st.selectbox(
                    "Bedrooms Configuration (BHK) *",
                    options=[1, 2, 3, 4, 5, 6],
                    index=2,
                    help="Number of bedrooms, hall, and kitchen."
                )

                total_sqft = st.number_input(
                    "Total Living Area (in Square Feet) *",
                    min_value=200,
                    max_value=15000,
                    value=1500,
                    step=25,
                    help="Living / usable floor area in square feet."
                )

                with st.expander("📐 Local Gujarat Unit Converter (Gaj / Vraj / Sq.Yard / Sq.Meter)"):
                    st.caption("Convert traditional Gujarat measurements directly into Square Feet:")
                    conv_type = st.selectbox("Measurement Unit:", ["Square Yards (Gaj / Vraj / Sq.Yrd)", "Square Meters (Sq.Mtr)"])
                    conv_input = st.number_input("Value:", min_value=1.0, value=150.0, step=5.0)
                    if conv_type.startswith("Square Yards"):
                        sqft_equiv = conv_input * 9.0
                        st.info(f"👉 **{conv_input} sq.yrd (Gaj)** = **{sqft_equiv:.1f} sq.ft** (Enter this value in Total Living Area)")
                    else:
                        sqft_equiv = conv_input * 10.7639
                        st.info(f"👉 **{conv_input} sq.m** = **{sqft_equiv:.1f} sq.ft**")

            with form_c2:
                area_type = st.selectbox(
                    "Area Measurement Type",
                    options=["Super Area", "Carpet Area"],
                    index=0,
                    help="Carpet Area is actual usable space; Super Area includes proportionate common areas."
                )

                status = st.selectbox(
                    "Construction Status",
                    options=["Ready to Move", "Under Construction"],
                    index=0
                )

                furnishing = st.selectbox(
                    "Furnishing Status",
                    options=["Unfurnished", "Semi-Furnished", "Furnished"],
                    index=0
                )

                transaction = st.selectbox(
                    "Transaction Type",
                    options=["Resale", "New Property"],
                    index=0
                )

            st.markdown("<br>", unsafe_allow_html=True)
            submit_valuation = st.form_submit_button("💰 Calculate Estimated Price", use_container_width=True, type="primary")

    if submit_valuation:
        property_inputs = {
            "locality": locality,
            "bhk": bhk,
            "total_sqft": total_sqft,
            "type_area": area_type,
            "status": status,
            "furnishing": furnishing,
            "transaction": transaction
        }

        try:
            with st.spinner("Processing machine learning prediction pipeline..."):
                result = predictor.predict(property_inputs)

            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("### 🏆 Estimated Valuation Result")

            r_col1, r_col2 = st.columns([1.3, 0.7], gap="large")

            with r_col1:
                st.markdown(f"""
                <div class="result-container-card">
                    <span class="result-badge-pill">ESTIMATED MARKET VALUE</span>
                    <div class="result-main-price">{result['formatted_denomination']}</div>
                    <div class="result-exact-rupees">{result['formatted_rupees']}</div>
                    
                    <div class="result-margin-box">
                        <strong>📊 Empirical Model Margin (± Held-Out Test MAE):</strong><br>
                        {result['lower_bound_formatted']} &nbsp;—&nbsp; {result['upper_bound_formatted']}
                    </div>

                    <div style="margin-top: 1.2rem;">
                        <span class="property-pill-tag">📍 {locality}</span>
                        <span class="property-pill-tag">🛏️ {bhk} BHK</span>
                        <span class="property-pill-tag">📐 {total_sqft:,} sq.ft</span>
                        <span class="property-pill-tag">🏷️ {area_type}</span>
                        <span class="property-pill-tag">🏢 {status}</span>
                        <span class="property-pill-tag">🛋️ {furnishing}</span>
                        <span class="property-pill-tag">🤝 {transaction}</span>
                    </div>

                    <div class="disclaimer-card">
                        ⚠️ <strong>Official Valuation Disclaimer</strong>: {result['disclaimer']}
                    </div>
                </div>
                """, unsafe_allow_html=True)

            with r_col2:
                st.markdown(f"""
                <div class="kpi-card" style="margin-top: 1.5rem;">
                    <div class="kpi-label">Calculated Rate / Sq.Ft</div>
                    <div class="kpi-value" style="color: #158A83;">{result['rate_per_sqft_formatted']}</div>
                    <div class="kpi-sub">Estimated for {locality}</div>
                </div>
                """, unsafe_allow_html=True)

                st.markdown(f"""
                <div class="kpi-card" style="margin-top: 1rem;">
                    <div class="kpi-label">Predictor Pipeline</div>
                    <div class="kpi-value" style="font-size: 1.3rem;">{result['model_name']}</div>
                    <div class="kpi-sub">Held-Out Test MAE: ± ₹{result['test_mae_lakhs']:.1f} L</div>
                </div>
                """, unsafe_allow_html=True)

            # Interactive Home Loan EMI & Financing Calculator
            st.markdown("<br>", unsafe_allow_html=True)
            with st.expander("🏦 Home Loan EMI & Financing Calculator", expanded=True):
                st.markdown("Calculate estimated monthly mortgage installments based on this property valuation:")
                ec1, ec2, ec3 = st.columns(3)
                with ec1:
                    down_pct = st.slider("Down Payment (%)", min_value=10, max_value=50, value=20, step=5)
                with ec2:
                    interest_rate = st.slider("Interest Rate (% p.a.)", min_value=7.0, max_value=12.0, value=8.5, step=0.25)
                with ec3:
                    tenure = st.selectbox("Loan Tenure (Years)", options=[10, 15, 20, 25, 30], index=2)

                emi_data = calculate_emi(
                    property_price_lakhs=result["predicted_price_lakhs"],
                    interest_rate_pct=interest_rate,
                    tenure_years=tenure,
                    down_payment_pct=down_pct
                )

                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Monthly EMI", emi_data["monthly_emi_formatted"])
                m2.metric("Down Payment", emi_data["down_payment_formatted"])
                m3.metric("Loan Principal", emi_data["loan_principal_formatted"])
                m4.metric("Total Interest Payable", emi_data["total_interest_formatted"])

        except Exception as e:
            st.error(f"Valuation error: {e}")

def render_analytics_view(df_clean, metrics_report):
    st.markdown("## 📈 Ahmedabad Real Estate Market Intelligence")
    st.markdown("Interactive analytical dashboards and genuine metrics computed exclusively from verified Ahmedabad property records.")

    if df_clean is None:
        st.warning("Processed dataset not found. Please run `python train.py` first.")
        return

    tab1, tab2, tab3, tab4 = st.tabs(["Locality Insights", "BHK & Area Trends", "Model Benchmark", "Dataset Explorer"])

    with tab1:
        st.markdown("#### Locality Price Distribution & Listing Volumes")
        
        # Interactive Plotly Locality Box Plot / Bar Chart
        top15_locs = df_clean[df_clean["locality"] != "Other"]["locality"].value_counts().head(15).index
        df_top15 = df_clean[df_clean["locality"].isin(top15_locs)]
        med_order = df_top15.groupby("locality")["price_lakhs"].median().sort_values(ascending=True).index

        fig_loc_box = px.box(
            df_top15,
            x="price_lakhs",
            y="locality",
            category_orders={"locality": list(med_order)},
            color="locality",
            title="Price Spread Across Top 15 Ahmedabad Localities (₹ Lakhs)",
            labels={"price_lakhs": "Price (₹ in Lakhs)", "locality": "Locality"}
        )
        fig_loc_box.update_layout(
            paper_bgcolor="#FFFFFF",
            plot_bgcolor="#F8FAFC",
            showlegend=False,
            margin=dict(l=20, r=20, t=40, b=20),
            font=dict(family="Plus Jakarta Sans", color="#202B38")
        )
        st.plotly_chart(fig_loc_box, use_container_width=True)

        st.markdown("#### Top 15 Ahmedabad Localities Summary Table")
        loc_summary = df_clean[df_clean["locality"] != "Other"].groupby("locality").agg(
            Listings=("price_lakhs", "count"),
            Median_Price_Lakhs=("price_lakhs", "median"),
            Mean_Price_Lakhs=("price_lakhs", "mean"),
            Median_Area_SqFt=("total_sqft", "median")
        ).sort_values("Listings", ascending=False).head(15).reset_index()

        loc_summary["Median_Price"] = loc_summary["Median_Price_Lakhs"].apply(lambda v: f"₹ {v:.1f} Lakhs")
        loc_summary["Mean_Price"] = loc_summary["Mean_Price_Lakhs"].apply(lambda v: f"₹ {v:.1f} Lakhs")
        loc_summary["Median_Area"] = loc_summary["Median_Area_SqFt"].apply(lambda v: f"{int(v):,} sqft")

        st.dataframe(
            loc_summary[["locality", "Listings", "Median_Price", "Mean_Price", "Median_Area"]],
            use_container_width=True,
            hide_index=True
        )

    with tab2:
        c1, c2 = st.columns(2, gap="medium")

        with c1:
            # Interactive BHK Distribution & Median Price
            bhk_stats = df_clean.groupby("bhk").agg(
                Count=("price_lakhs", "count"),
                Median_Price=("price_lakhs", "median")
            ).reset_index()

            fig_bhk = px.bar(
                bhk_stats,
                x="bhk",
                y="Median_Price",
                color="Count",
                color_continuous_scale=["#158A83", "#142A43"],
                title="Median Price by BHK Configuration (₹ Lakhs)",
                labels={"bhk": "BHK Configuration", "Median_Price": "Median Price (₹ Lakhs)", "Count": "Listings"}
            )
            fig_bhk.update_layout(
                paper_bgcolor="#FFFFFF",
                plot_bgcolor="#F8FAFC",
                margin=dict(l=20, r=20, t=40, b=20),
                font=dict(family="Plus Jakarta Sans", color="#202B38")
            )
            st.plotly_chart(fig_bhk, use_container_width=True)

        with c2:
            # Interactive Area vs Price Scatter Plot with Trendline
            # Sample for fast web rendering if large
            sample_df = df_clean.sample(min(1500, len(df_clean)), random_state=42)
            fig_scatter = px.scatter(
                sample_df,
                x="total_sqft",
                y="price_lakhs",
                color="bhk",
                trendline="ols",
                title="Living Area vs. Price (with OLS Trendline)",
                labels={"total_sqft": "Total Area (sq.ft)", "price_lakhs": "Price (₹ Lakhs)", "bhk": "BHK"},
                hover_data=["locality", "status"]
            )
            fig_scatter.update_layout(
                paper_bgcolor="#FFFFFF",
                plot_bgcolor="#F8FAFC",
                margin=dict(l=20, r=20, t=40, b=20),
                font=dict(family="Plus Jakarta Sans", color="#202B38")
            )
            st.plotly_chart(fig_scatter, use_container_width=True)

        fig_heat = settings.FIGURES_DIR / "correlation_heatmap.png"
        if fig_heat.exists():
            st.image(str(fig_heat), caption="Correlation Matrix (Numerical Features)", use_container_width=True)

    with tab3:
        st.markdown("#### Machine Learning Algorithm Comparison (5-Fold Cross Validation)")
        if metrics_report and "cv_metrics" in metrics_report:
            cv_data = metrics_report["cv_metrics"]
            rows = []
            for m_name, m_vals in cv_data.items():
                rows.append({
                    "Algorithm": m_name,
                    "CV MAE (₹ Lakhs)": f"₹ {m_vals['cv_mae_lakhs']:.2f} L",
                    "CV RMSE (₹ Lakhs)": f"₹ {m_vals['cv_rmse_lakhs']:.2f} L",
                    "CV R² Score": f"{m_vals['cv_r2']:.4f}",
                    "Status": "🏆 Winner" if m_name == metrics_report["model_name"] else "Candidate"
                })
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.info("Metrics report not available yet. Please run `python train.py`.")

    with tab4:
        st.markdown("#### Cleaned Dataset Search & Export")
        search_loc = st.text_input("Filter by locality name (e.g. Shela, Bopal, Bodakdev):", "")
        df_filtered = df_clean.copy()
        if search_loc.strip():
            df_filtered = df_filtered[df_filtered["locality"].str.contains(search_loc.strip(), case=False, na=False)]

        st.dataframe(
            df_filtered[["locality", "bhk", "total_sqft", "type_area", "status", "furnishing", "transaction", "price_lakhs"]].head(100),
            use_container_width=True,
            hide_index=True
        )

        csv_data = df_filtered.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Filtered Data as CSV",
            data=csv_data,
            file_name="ahmedabad_properties_filtered.csv",
            mime="text/csv"
        )

def render_about_view(metrics_report):
    st.markdown("## ℹ️ About Ahmedabad House Price Predictor AI")

    st.markdown(r"""
    ### 1. Project Identity & Geographic Scope
    **Ahmedabad House Price Predictor AI** is an end-to-end Machine Learning web application engineered exclusively for residential real estate valuation across **Ahmedabad, Gujarat, India**.
    
    - **Geographic Focus**: Ahmedabad municipal and suburban residential zones (Shela, Bodakdev, Bopal, Thaltej, Satellite, Ambli, Gota, Chandkheda, Science City, Vaishnodevi Circle, Vastral, etc.).
    - **Strict Location Compliance**: 100% verified Ahmedabad property listings. Zero records from Bengaluru, Mumbai, Delhi, Pune, or other non-Ahmedabad locations. No synthetic or generated records.

    ### 2. Dataset Attribution & Licensing
    - **Primary Dataset Candidate**: [HansikaPrabodini/Ahmedabad-Flat-Price-Dataset](https://github.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset)
    - **Download Source**: `https://raw.githubusercontent.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset/main/ahmedabad.csv`
    - **License**: Public / Open Educational Dataset
    - **Local Storage**: `data/raw/ahmedabad.csv` (Raw original data preserved immutably).

    ### 3. Machine Learning Architecture
    - **Preprocessing Pipeline**: Scikit-Learn `ColumnTransformer` featuring:
      - Numerical: `SimpleImputer(strategy='median')` + `StandardScaler()`
      - Categorical: `SimpleImputer(strategy='most_frequent')` + `OneHotEncoder(handle_unknown='ignore')`
    - **Candidate Models Evaluated (5-Fold Cross Validation)**:
      1. `DummyRegressor(strategy='median')` (Baseline)
      2. `Ridge Regression`
      3. `Extra Trees Regressor`
      4. `Random Forest Regressor` (Selected Winner: Held-out Test $R^2 = 0.9138$, $\text{MAE} = \pm ₹ 30.01 \text{ Lakhs}$)
    - **Zero Target Leakage Guarantee**: Price per square foot (`price_sqft`) and target-derived rates are strictly banned from feature inputs.

    ### 4. Known Dataset Limitations
    - Historical listing prices reflect seller ask quotes at the time of scraping, which may differ slightly from final registered deed sale prices after negotiation.
    - Commercial properties, agricultural lands, and plots are intentionally excluded; model is calibrated strictly for residential apartments, flats, and penthouses.

    ### 5. Legal & Commercial Disclaimer
    This application is an educational and analytical tool designed to provide statistical price estimates. The predictions generated do not constitute certified bank valuations, government circle rate certificates, or legal appraisal opinions.
    """)

    if metrics_report:
        st.markdown(f"**Last Model Calibration**: `{metrics_report.get('evaluated_at', 'N/A')}`")

if __name__ == "__main__":
    main()
