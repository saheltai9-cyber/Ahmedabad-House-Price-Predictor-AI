"""
Unit tests for visual assets, local image files, and paths.
Ensures zero broken image links and validates local decoded images.
"""
from pathlib import Path
from PIL import Image
from config import settings

REQUIRED_IMAGES = [
    "hero_skyline.jpg",
    "ahmedabad_architecture.jpg",
    "ahmedabad_landmark.jpg",
    "ahmedabad_living.jpg",
    "logo.png"
]

def test_images_directory_exists():
    assert settings.IMAGES_DIR.exists(), f"Images directory missing: {settings.IMAGES_DIR}"

def test_all_required_images_exist_and_decode():
    for img_name in REQUIRED_IMAGES:
        img_path = settings.IMAGES_DIR / img_name
        assert img_path.exists(), f"Missing required visual asset: {img_path}"
        min_size = 500 if img_name == "logo.png" else 10000
        assert img_path.stat().st_size > min_size, f"Image file is suspiciously small or corrupted: {img_path}"

        # Decode image using Pillow
        with Image.open(img_path) as img:
            width, height = img.size
            if img_name == "logo.png":
                assert width >= 120 and height >= 120
            else:
                assert width >= 400, f"{img_name} width too small: {width}"
                assert height >= 300, f"{img_name} height too small: {height}"
            assert img.format in ["JPEG", "PNG", "WEBP"], f"Unexpected image format: {img.format}"

def test_no_external_broken_image_urls_in_app():
    app_file = settings.BASE_DIR / "app.py"
    content = app_file.read_text(encoding="utf-8")
    # Verify no unhandled external wikipedia or unverified links are used in st.image
    assert "upload.wikimedia.org" not in content, "Found brittle external wikipedia image link in app.py"

