"""
Unit tests for data preprocessing and parsing functions.
"""
import pytest
import numpy as np
import pandas as pd
from src.preprocessing import (
    parse_price,
    parse_area,
    extract_bhk,
    extract_locality,
    clean_locality_name,
    extract_furnishing,
    extract_transaction,
    extract_status,
    extract_type_area,
    clean_dataset
)

def test_parse_price():
    # Test Lac parsing
    assert parse_price("₹48.1 Lac ") == pytest.approx(48.1)
    assert parse_price("50 Lac") == pytest.approx(50.0)
    assert parse_price("₹ 95.5 Lakh") == pytest.approx(95.5)

    # Test Cr parsing (1 Cr = 100 Lakhs)
    assert parse_price("₹2.5 Cr") == pytest.approx(250.0)
    assert parse_price("1.25 Cr ") == pytest.approx(125.0)

    # Test unpriced / invalid
    assert np.isnan(parse_price("Call for Price"))
    assert np.isnan(parse_price("Price on Request"))
    assert np.isnan(parse_price(None))
    assert np.isnan(parse_price(np.nan))

def test_parse_area_units():
    # Test sqft (1.0)
    assert parse_area("710 sqft") == pytest.approx(710.0)
    assert parse_area("1,250 sqft") == pytest.approx(1250.0)

    # Test sqyrd (1 sq yard = 9 sq ft)
    assert parse_area("100 sqyrd") == pytest.approx(900.0)
    assert parse_area("155 sqyrd") == pytest.approx(1395.0)

    # Test sqm (1 sq meter = 10.7639 sq ft)
    assert parse_area("100 sqm") == pytest.approx(1076.39)

    # Test invalid / missing unit
    assert np.isnan(parse_area("1200"))
    assert np.isnan(parse_area("Unknown"))
    assert np.isnan(parse_area(np.nan))

def test_extract_bhk():
    assert extract_bhk("2 BHK Apartment for Sale in Shela Ahmedabad") == 2
    assert extract_bhk("3 BHK Flat in Bodakdev") == 3
    assert extract_bhk("4 BHK Luxury Penthouse in Ambli") == 4
    assert extract_bhk("1 BHK Studio Apartment in Jagatpur") == 1
    assert np.isnan(extract_bhk("Residential Plot for Sale in Ahmedabad"))

def test_extract_locality():
    loc1 = extract_locality("2 BHK Apartment for Sale in Vivaan Aura, Zundal Ahmedabad")
    assert "Zundal" in loc1

    loc2 = extract_locality("3 BHK Apartment for Sale in Shela Ahmedabad")
    assert loc2 == "Shela"

    loc3 = extract_locality("4 BHK Flat in Bodakdev Ahmedabad")
    assert loc3 == "Bodakdev"

    loc_blank = extract_locality("2 BHK Apartment for Sale in Ahmedabad")
    assert loc_blank == "Other"

def test_clean_locality_name():
    assert clean_locality_name("Sg Highway") == "Sarkhej Gandhinagar Highway"
    assert clean_locality_name("Sp Ring Road") == "Sardar Patel Ring Road"
    assert clean_locality_name("  shela  ") == "Shela"

def test_extract_furnishing():
    row_unfurnished = pd.Series({"furnishing": "Unfurnished", "transaction": "Resale", "floor": "2 out of 5"})
    assert extract_furnishing(row_unfurnished) == "Unfurnished"

    row_shifted = pd.Series({"furnishing": "Vivaan Aura", "transaction": "Furnished", "floor": "New Property"})
    assert extract_furnishing(row_shifted) == "Furnished"

    row_semi = pd.Series({"furnishing": "Semi-Furnished", "transaction": "New Property", "floor": "4 out of 5"})
    assert extract_furnishing(row_semi) == "Semi-Furnished"

def test_extract_transaction():
    row_resale = pd.Series({"transaction": "Resale", "floor": "2 out of 5", "furnishing": "Unfurnished"})
    assert extract_transaction(row_resale) == "Resale"

    row_new = pd.Series({"transaction": "New Property", "floor": "5 out of 14", "furnishing": "Furnished"})
    assert extract_transaction(row_new) == "New Property"

def test_extract_status():
    assert extract_status("Ready to Move") == "Ready to Move"
    assert extract_status("Poss. by Dec '26") == "Under Construction"
    assert extract_status("Under Construction") == "Under Construction"

def test_clean_dataset_pipeline():
    sample_raw = pd.DataFrame([
        {
            "Unnamed: 0": 0,
            "Title": "2 BHK Apartment for Sale in Vivaan Aura, Zundal Ahmedabad",
            "type_area": "Super Area",
            "value_area": "155 sqyrd",
            "status": "Poss. by Dec '26",
            "floor": "New Property",
            "transaction": "Unfurnished",
            "furnishing": "Vivaan Aura",
            "facing": "2",
            "price": "₹48.1 Lac ",
            "price_sqft": "₹3,444 per sqft ",
            "description": "Multistorey Apartment for Sale in Zundal, Ahmedabad."
        },
        {
            "Unnamed: 0": 1,
            "Title": "3 BHK Apartment for Sale in Orchid, Shela Ahmedabad",
            "type_area": "Carpet Area",
            "value_area": "1200 sqft",
            "status": "Ready to Move",
            "floor": "4 out of 5",
            "transaction": "Resale",
            "furnishing": "Furnished",
            "facing": "East",
            "price": "₹95 Lac ",
            "price_sqft": "₹7,916 per sqft ",
            "description": "Prime location in Shela."
        },
        # Duplicate row
        {
            "Unnamed: 0": 2,
            "Title": "3 BHK Apartment for Sale in Orchid, Shela Ahmedabad",
            "type_area": "Carpet Area",
            "value_area": "1200 sqft",
            "status": "Ready to Move",
            "floor": "4 out of 5",
            "transaction": "Resale",
            "furnishing": "Furnished",
            "facing": "East",
            "price": "₹95 Lac ",
            "price_sqft": "₹7,916 per sqft ",
            "description": "Prime location in Shela."
        },
        # Extreme bogus outlier row
        {
            "Unnamed: 0": 3,
            "Title": "1 BHK Apartment in Satellite Ahmedabad",
            "type_area": "Super Area",
            "value_area": "10 sqft",
            "status": "Ready to Move",
            "floor": "1 out of 5",
            "transaction": "Resale",
            "furnishing": "Unfurnished",
            "facing": "North",
            "price": "₹50000 Lac ",
            "price_sqft": "₹50000000 per sqft ",
            "description": "Bogus record."
        }
    ])
    
    df_clean, metrics = clean_dataset(sample_raw)
    assert len(df_clean) == 2  # 1 duplicate dropped, 1 bogus outlier dropped
    assert "price_sqft" not in df_clean.columns  # Leakage prevention
    assert "derived_rate" not in df_clean.columns
    assert "price_lakhs" in df_clean.columns
    assert "total_sqft" in df_clean.columns
    assert metrics["listing_duplicates_removed"] == 1

