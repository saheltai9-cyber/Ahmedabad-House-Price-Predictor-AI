"""
Unit and integration tests for Ahmedabad House Price prediction pipeline.
"""
import pytest
import numpy as np
from pathlib import Path
from src.prediction import (
    format_inr_rupees,
    format_denomination,
    calculate_emi,
    AhmedabadPricePredictor
)
from config import settings

def test_currency_formatting():
    assert format_inr_rupees(48.5) == "₹ 48,50,000"
    assert format_inr_rupees(100.0) == "₹ 1,00,00,000"
    assert format_inr_rupees(250.75) == "₹ 2,50,75,000"
    assert format_inr_rupees(0) == "₹ 0"

def test_denomination_formatting():
    assert format_denomination(48.5) == "₹ 48.50 Lakhs"
    assert format_denomination(99.0) == "₹ 99.00 Lakhs"
    assert format_denomination(100.0) == "₹ 1.00 Crore"
    assert format_denomination(250.0) == "₹ 2.50 Crores"

def test_predictor_input_validation():
    # We can test validation without needing model weights loaded
    predictor = AhmedabadPricePredictor.__new__(AhmedabadPricePredictor)
    predictor.metadata = {}

    # Valid input
    valid_input = {
        "locality": "Shela",
        "bhk": 3,
        "total_sqft": 1450,
        "type_area": "Super Area",
        "status": "Ready to Move",
        "furnishing": "Unfurnished",
        "transaction": "Resale"
    }
    is_valid, err = predictor.validate_inputs(valid_input)
    assert is_valid is True
    assert err is None

    # Invalid BHK
    bad_bhk = valid_input.copy()
    bad_bhk["bhk"] = 0
    is_valid, err = predictor.validate_inputs(bad_bhk)
    assert is_valid is False

    # Invalid Area (too small)
    bad_area = valid_input.copy()
    bad_area["total_sqft"] = 50
    is_valid, err = predictor.validate_inputs(bad_area)
    assert is_valid is False

    # Invalid Locality
    bad_loc = valid_input.copy()
    bad_loc["locality"] = ""
    is_valid, err = predictor.validate_inputs(bad_loc)
    assert is_valid is False

def test_predictor_inference_if_model_exists():
    """
    If the model has been trained, tests complete end-to-end inference output schema.
    """
    if not settings.MODEL_PATH.exists():
        pytest.skip("Model artifact not yet trained; skipping live model evaluation test.")

    predictor = AhmedabadPricePredictor(
        model_path=settings.MODEL_PATH,
        metadata_path=settings.METADATA_PATH
    )

    sample_property = {
        "locality": "Shela",
        "bhk": 3,
        "total_sqft": 1500,
        "type_area": "Carpet Area",
        "status": "Ready to Move",
        "furnishing": "Semi-Furnished",
        "transaction": "Resale"
    }

    result = predictor.predict(sample_property)

    assert "predicted_price_lakhs" in result
    assert result["predicted_price_lakhs"] > 10.0
    assert "formatted_rupees" in result
    assert result["formatted_rupees"].startswith("₹")
    assert "formatted_denomination" in result
    assert "lower_bound_lakhs" in result
    assert "upper_bound_lakhs" in result
    assert result["lower_bound_lakhs"] <= result["predicted_price_lakhs"] <= result["upper_bound_lakhs"]
    assert "rate_per_sqft" in result
    assert result["rate_per_sqft"] > 1000
    assert "disclaimer" in result

def test_calculate_emi():
    # 100 Lakhs (1 Crore), 20% down payment = 80 Lakhs loan, 8.5% interest, 20 years
    emi_res = calculate_emi(property_price_lakhs=100.0, interest_rate_pct=8.5, tenure_years=20, down_payment_pct=20.0)
    assert emi_res["monthly_emi"] > 50000
    assert emi_res["monthly_emi_formatted"].startswith("₹")
    assert emi_res["down_payment_formatted"] == "₹ 20,00,000"
    assert emi_res["loan_principal_formatted"] == "₹ 80,00,000"
    assert emi_res["tenure_months"] == 240

def test_unseen_locality_handling():
    if not settings.MODEL_PATH.exists():
        pytest.skip("Model not found")
    predictor = AhmedabadPricePredictor(settings.MODEL_PATH, settings.METADATA_PATH)
    # Test completely unseen locality
    prop = {
        "locality": "NonExistentAhmedabadSectorXYZ",
        "bhk": 2,
        "total_sqft": 1100,
        "type_area": "Super Area",
        "status": "Ready to Move",
        "furnishing": "Unfurnished",
        "transaction": "Resale"
    }
    res = predictor.predict(prop)
    assert "predicted_price_lakhs" in res
    assert np.isfinite(res["predicted_price_lakhs"])
    assert res["predicted_price_lakhs"] > 0

def test_multiple_property_configurations():
    if not settings.MODEL_PATH.exists():
        pytest.skip("Model not found")
    predictor = AhmedabadPricePredictor(settings.MODEL_PATH, settings.METADATA_PATH)
    configs = [
        {"locality": "Bopal", "bhk": 1, "total_sqft": 600, "type_area": "Carpet Area", "status": "Ready to Move", "furnishing": "Unfurnished", "transaction": "Resale"},
        {"locality": "Bodakdev", "bhk": 4, "total_sqft": 3200, "type_area": "Super Area", "status": "Ready to Move", "furnishing": "Furnished", "transaction": "Resale"},
        {"locality": "Gota", "bhk": 2, "total_sqft": 1050, "type_area": "Carpet Area", "status": "Under Construction", "furnishing": "Semi-Furnished", "transaction": "New Property"},
        {"locality": "Satellite", "bhk": 3, "total_sqft": 1800, "type_area": "Super Area", "status": "Ready to Move", "furnishing": "Semi-Furnished", "transaction": "Resale"},
        {"locality": "Ambli", "bhk": 5, "total_sqft": 5500, "type_area": "Super Area", "status": "Under Construction", "furnishing": "Furnished", "transaction": "New Property"},
    ]
    for cfg in configs:
        res = predictor.predict(cfg)
        assert np.isfinite(res["predicted_price_lakhs"])
        assert res["predicted_price_lakhs"] > 5.0
        assert res["rate_per_sqft"] > 1000

def test_no_target_leakage_in_feature_definitions():
    import json
    assert "price_sqft" not in settings.NUMERICAL_FEATURES
    assert "price_sqft" not in settings.CATEGORICAL_FEATURES
    assert "derived_rate" not in settings.NUMERICAL_FEATURES
    assert "rate" not in settings.NUMERICAL_FEATURES
    for leak in settings.LEAKAGE_COLUMNS:
        assert leak in ["price", "price_sqft", "derived_rate", "rate"]

def test_model_metrics_integrity():
    if not settings.METRICS_PATH.exists():
        pytest.skip("Metrics report not found")
    import json
    with open(settings.METRICS_PATH, "r", encoding="utf-8") as f:
        metrics = json.load(f)
    assert metrics["model_name"] == "Random Forest"
    test_m = metrics["test_metrics"]
    assert 0.85 <= test_m["r2_score"] <= 1.0
    assert 10.0 <= test_m["mae_lakhs"] <= 50.0
    assert 20.0 <= test_m["rmse_lakhs"] <= 80.0



