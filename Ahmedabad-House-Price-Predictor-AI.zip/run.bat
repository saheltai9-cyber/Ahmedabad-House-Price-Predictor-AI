@echo off
setlocal enabledelayedexpansion

title Ahmedabad House Price Predictor AI - Launcher

echo ======================================================================
echo          AHMEDABAD HOUSE PRICE PREDICTOR AI - STARTUP SYSTEM
echo ======================================================================
echo.

cd /d "%~dp0"

:: 1. Check Python installation
where python >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Python is not found in your PATH!
    echo Please install Python 3.10+ from https://www.python.org/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

echo [OK] Python detected:
python --version
echo.

:: 2. Optional Virtual Environment Setup
if not exist "venv" (
    echo [INFO] Creating Python virtual environment (venv)...
    python -m venv venv
    if %ERRORLEVEL% neq 0 (
        echo [WARNING] Could not create virtual environment. Using system Python.
    ) else (
        echo [OK] Virtual environment created successfully.
    )
)

if exist "venv\Scripts\activate.bat" (
    echo [INFO] Activating virtual environment...
    call venv\Scripts\activate.bat
)

:: 3. Check and Install Requirements
echo [INFO] Checking dependencies...
python -c "import streamlit, sklearn, pandas, joblib, matplotlib, seaborn, plotly, PIL" >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [INFO] Installing required dependencies from requirements.txt...
    pip install -r requirements.txt
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to install dependencies. Please check your internet connection.
        pause
        exit /b 1
    )
    echo [OK] Dependencies installed successfully.
) else (
    echo [OK] All required packages are already installed.
)
echo.

:: 4. Check Raw Dataset
if not exist "data\raw\ahmedabad.csv" (
    echo [INFO] Ahmedabad dataset missing from data\raw\ahmedabad.csv.
    echo [INFO] Initiating automated download...
    python -c "from src.data_loader import download_dataset; download_dataset()"
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Failed to download dataset.
        echo Please ensure internet access or place ahmedabad.csv in data\raw\
        pause
        exit /b 1
    )
) else (
    echo [OK] Raw Ahmedabad dataset verified: data\raw\ahmedabad.csv
)
echo.

:: 5. Check Trained Model Pipeline
if not exist "models\ahmedabad_house_price_model.joblib" (
    echo [INFO] No trained model artifact found.
    echo [INFO] Starting automatic end-to-end training and cross-validation...
    python train.py
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Training pipeline encountered an error.
        pause
        exit /b 1
    )
    echo [OK] Model trained and saved successfully.
) else (
    echo [OK] Trained model found: models\ahmedabad_house_price_model.joblib
    echo (Skipping redundant retraining. Run 'python train.py' manually if you wish to retrain.)
)
echo.

:: 6. Launch Streamlit Application
echo ======================================================================
echo  Launching Ahmedabad House Price Predictor AI web application...
echo  Local browser will open automatically at http://localhost:8501
echo  Press Ctrl+C in this terminal window to stop the application.
echo ======================================================================
echo.

streamlit run app.py --server.headless false

if %ERRORLEVEL% neq 0 (
    echo [ERROR] Streamlit exited with an error.
    pause
)

