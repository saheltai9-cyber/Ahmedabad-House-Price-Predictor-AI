"""
Dataset loader and validation module for Ahmedabad House Price Predictor AI.
Handles downloading, schema inspection, and verification of genuine Ahmedabad property data.
"""
import os
import sys
import logging
import urllib.request
import urllib.error
from pathlib import Path
from typing import Dict, Any, Tuple
import pandas as pd

# Allow running as script or imported module
if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config import settings
else:
    from config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Expected minimum schema signatures in genuine Ahmedabad dataset
EXPECTED_RAW_COLUMNS = ["Title", "value_area", "price"]

def download_dataset(
    url: str = settings.DATASET_URL,
    dest_path: Path = settings.RAW_DATA_PATH,
    force: bool = False
) -> Path:
    """
    Downloads the Ahmedabad flat price dataset if missing.
    Strictly verifies destination and never silently substitutes another dataset.
    """
    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    if dest_path.exists() and dest_path.stat().st_size > 1000 and not force:
        logger.info(f"Dataset already present at {dest_path} ({dest_path.stat().st_size} bytes).")
        return dest_path

    logger.info(f"Initiating download of verified Ahmedabad dataset from: {url}")
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AhmedabadHousePricePredictor/1.0"}
    req = urllib.request.Request(url, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            if response.status != 200:
                raise RuntimeError(f"HTTP Download failed with status {response.status}: {response.reason}")
            data = response.read()

        if len(data) < 1000:
            raise ValueError(f"Downloaded content suspiciously small ({len(data)} bytes). Expected valid CSV.")

        # Atomic write
        temp_dest = dest_path.with_suffix(".tmp")
        with open(temp_dest, "wb") as f:
            f.write(data)
        
        # Verify schema before final rename
        test_df = pd.read_csv(temp_dest, nrows=5)
        missing_cols = [c for c in EXPECTED_RAW_COLUMNS if c not in test_df.columns]
        if missing_cols:
            temp_dest.unlink(missing_ok=True)
            raise ValueError(
                f"Downloaded file does not match expected Ahmedabad schema. Missing columns: {missing_cols}"
            )

        if dest_path.exists():
            dest_path.unlink()
        temp_dest.rename(dest_path)
        logger.info(f"Dataset successfully downloaded and verified at {dest_path}")
        return dest_path

    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as e:
        logger.error(f"Network error downloading Ahmedabad dataset: {e}")
        raise ConnectionError(
            f"Failed to download Ahmedabad dataset from {url}. "
            "Please check internet connection or manually place 'ahmedabad.csv' in 'data/raw/' directory."
        ) from e
    except Exception as e:
        logger.error(f"Unexpected error during dataset download: {e}")
        raise

def load_raw_dataset(filepath: Path = settings.RAW_DATA_PATH) -> pd.DataFrame:
    """
    Loads the raw Ahmedabad dataset into a pandas DataFrame.
    Guarantees raw data immutability.
    """
    filepath = Path(filepath)
    if not filepath.exists():
        download_dataset(dest_path=filepath)

    logger.info(f"Loading raw dataset from {filepath}...")
    df = pd.read_csv(filepath, encoding="utf-8")
    
    # Validation of required columns
    for col in EXPECTED_RAW_COLUMNS:
        if col not in df.columns:
            raise KeyError(
                f"Required column '{col}' missing from {filepath}. "
                "Dataset appears corrupted or incompatible."
            )

    logger.info(f"Raw dataset loaded successfully: {df.shape[0]} rows, {df.shape[1]} columns.")
    return df

def inspect_raw_schema(df: pd.DataFrame) -> Dict[str, Any]:
    """
    Inspects and reports column names, data types, and missing value counts.
    """
    schema_info = {
        "row_count": int(df.shape[0]),
        "column_count": int(df.shape[1]),
        "columns": list(df.columns),
        "data_types": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "missing_values": {col: int(count) for col, count in df.isnull().sum().items()},
        "duplicate_rows": int(df.duplicated().sum())
    }
    return schema_info

def get_dataset_provenance() -> Dict[str, str]:
    """
    Returns verified dataset source, location, and licensing information.
    """
    return {
        "target_city": "Ahmedabad, Gujarat, India",
        "dataset_name": "Ahmedabad Flat Price Dataset",
        "source_url": settings.DATASET_URL,
        "repository_url": settings.DATASET_REPO,
        "license": settings.DATASET_LICENSE,
        "description": settings.DATASET_DESCRIPTION,
        "strict_city_filter": "Ahmedabad records only. Zero Bengaluru or other city data."
    }

if __name__ == "__main__":
    settings.init_directories()
    # Test loader
    df_raw = load_raw_dataset()
    info = inspect_raw_schema(df_raw)
    print("Schema Info Summary:")
    print(f"- Rows: {info['row_count']}, Columns: {info['column_count']}")
    print(f"- Duplicate rows: {info['duplicate_rows']}")
    print("- Columns:", info["columns"])

