"""
Model training, cross-validation, evaluation, and serialization module for Ahmedabad House Price Predictor AI.
Compares DummyRegressor baseline, Ridge, RandomForest, and ExtraTrees using 5-fold CV and held-out test evaluation.
"""
import sys
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Tuple
import joblib
import numpy as np
import pandas as pd
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split, cross_validate, KFold
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config import settings
    from src.feature_engineering import build_preprocessor, prepare_features_and_target
else:
    from config import settings
    from src.feature_engineering import build_preprocessor, prepare_features_and_target

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

def get_candidate_models(random_state: int = settings.RANDOM_SEED) -> Dict[str, Any]:
    """
    Returns candidate regression estimators as specified in project requirements:
    1. Dummy Regressor (Median baseline)
    2. Ridge Regression
    3. Random Forest Regressor
    4. Extra Trees Regressor
    """
    return {
        "Dummy Baseline": DummyRegressor(strategy="median"),
        "Ridge Regression": Ridge(alpha=1.0, random_state=random_state),
        "Random Forest": RandomForestRegressor(n_estimators=100, random_state=random_state, n_jobs=-1),
        "Extra Trees": ExtraTreesRegressor(n_estimators=100, random_state=random_state, n_jobs=-1),
    }

def evaluate_models_cv(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    preprocessor: Any,
    cv_folds: int = settings.CV_FOLDS,
    random_state: int = settings.RANDOM_SEED
) -> Dict[str, Dict[str, float]]:
    """
    Performs K-Fold cross-validation on training set for all candidate models.
    Returns dictionary of mean CV metrics (MAE, RMSE, R²).
    """
    logger.info(f"Running {cv_folds}-fold cross validation across candidate models...")
    kfold = KFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
    candidates = get_candidate_models(random_state)
    cv_results = {}

    scoring = {
        "mae": "neg_mean_absolute_error",
        "rmse": "neg_root_mean_squared_error",
        "r2": "r2"
    }

    for name, estimator in candidates.items():
        logger.info(f"Evaluating candidate model: {name}...")
        pipeline = Pipeline(steps=[
            ("preprocessor", preprocessor),
            ("regressor", estimator)
        ])
        
        cv_out = cross_validate(pipeline, X_train, y_train, cv=kfold, scoring=scoring, n_jobs=-1)
        
        mean_mae = float(-cv_out["test_mae"].mean())
        mean_rmse = float(-cv_out["test_rmse"].mean())
        mean_r2 = float(cv_out["test_r2"].mean())
        
        cv_results[name] = {
            "cv_mae_lakhs": round(mean_mae, 2),
            "cv_rmse_lakhs": round(mean_rmse, 2),
            "cv_r2": round(mean_r2, 4)
        }
        logger.info(f"--> {name} - CV MAE: ₹{mean_mae:.2f}L | CV RMSE: ₹{mean_rmse:.2f}L | CV R²: {mean_r2:.4f}")

    return cv_results

def select_best_model_name(cv_results: Dict[str, Dict[str, float]]) -> str:
    """
    Selects the best performing model based on highest cross-validated R² (and lowest RMSE).
    Baseline Dummy is excluded unless no other model is superior.
    """
    non_baseline = {k: v for k, v in cv_results.items() if "Dummy" not in k}
    if not non_baseline:
        return list(cv_results.keys())[0]
    
    # Sort by highest R2 score
    best_name = max(non_baseline.keys(), key=lambda k: non_baseline[k]["cv_r2"])
    return best_name

def train_and_evaluate(
    df: pd.DataFrame,
    test_size: float = settings.TEST_SPLIT_RATIO,
    random_state: int = settings.RANDOM_SEED
) -> Tuple[Pipeline, Dict[str, Any]]:
    """
    Executes complete training and evaluation pipeline:
    - 80/20 train-test split
    - 5-fold CV model selection
    - Final pipeline fit on train set
    - Final evaluation on held-out test set
    """
    logger.info("Preparing features and target...")
    X, y = prepare_features_and_target(df)

    logger.info(f"Splitting dataset: {int((1-test_size)*100)}% train, {int(test_size*100)}% test (seed={random_state})...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )
    logger.info(f"Train samples: {len(X_train)}, Test samples: {len(X_test)}")

    preprocessor = build_preprocessor()
    cv_metrics = evaluate_models_cv(X_train, y_train, preprocessor, cv_folds=settings.CV_FOLDS, random_state=random_state)

    best_model_name = select_best_model_name(cv_metrics)
    logger.info(f"Selected best model from CV: '{best_model_name}'")

    # Build final winning pipeline
    candidates = get_candidate_models(random_state)
    best_estimator = candidates[best_model_name]
    final_pipeline = Pipeline(steps=[
        ("preprocessor", build_preprocessor()),
        ("regressor", best_estimator)
    ])

    logger.info(f"Fitting final pipeline ({best_model_name}) on full training set...")
    final_pipeline.fit(X_train, y_train)

    # Evaluate on held-out test set
    logger.info("Evaluating selected model on held-out test set...")
    y_test_pred = final_pipeline.predict(X_test)

    test_mae = float(mean_absolute_error(y_test, y_test_pred))
    test_rmse = float(root_mean_squared_error(y_test, y_test_pred))
    test_r2 = float(r2_score(y_test, y_test_pred))

    logger.info(f"Held-out Test Results for {best_model_name}:")
    logger.info(f"- Test MAE: ₹{test_mae:.2f} Lakhs")
    logger.info(f"- Test RMSE: ₹{test_rmse:.2f} Lakhs")
    logger.info(f"- Test R² Score: {test_r2:.4f}")

    # Locality options supported in training set
    supported_localities = sorted([str(loc) for loc in df["locality"].unique() if loc != "Other"])
    supported_localities.append("Other")

    training_artifacts = {
        "best_model_name": best_model_name,
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "random_seed": random_state,
        "test_metrics": {
            "mae_lakhs": round(test_mae, 2),
            "rmse_lakhs": round(test_rmse, 2),
            "r2_score": round(test_r2, 4)
        },
        "cv_metrics_comparison": cv_metrics,
        "numerical_features": settings.NUMERICAL_FEATURES,
        "categorical_features": settings.CATEGORICAL_FEATURES,
        "target_feature": settings.TARGET_FEATURE,
        "supported_localities": supported_localities,
        "training_timestamp": datetime.now(timezone.utc).isoformat(),
        "city": "Ahmedabad, Gujarat, India"
    }

    return final_pipeline, training_artifacts

def save_model_artifacts(
    pipeline: Pipeline,
    artifacts: Dict[str, Any],
    model_path: Path = settings.MODEL_PATH,
    metadata_path: Path = settings.METADATA_PATH,
    metrics_path: Path = settings.METRICS_PATH
) -> None:
    """
    Saves trained pipeline joblib and metadata/metrics JSON files.
    """
    model_path = Path(model_path)
    model_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path = Path(metadata_path)
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metrics_path = Path(metrics_path)
    metrics_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"Saving trained pipeline to {model_path}...")
    joblib.dump(pipeline, model_path)

    logger.info(f"Saving model metadata to {metadata_path}...")
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(artifacts, f, indent=2)

    logger.info(f"Saving reports model metrics to {metrics_path}...")
    metrics_summary = {
        "model_name": artifacts["best_model_name"],
        "target_city": artifacts["city"],
        "test_metrics": artifacts["test_metrics"],
        "cv_metrics": artifacts["cv_metrics_comparison"],
        "evaluated_at": artifacts["training_timestamp"],
        "dataset_split": {
            "train_size": artifacts["train_samples"],
            "test_size": artifacts["test_samples"]
        }
    }
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metrics_summary, f, indent=2)

    logger.info("All model artifacts saved successfully.")

if __name__ == "__main__":
    from src.data_loader import load_raw_dataset
    from src.preprocessing import clean_dataset
    settings.init_directories()
    df_raw = load_raw_dataset()
    df_clean, _ = clean_dataset(df_raw)
    pipeline, artifacts = train_and_evaluate(df_clean)
    save_model_artifacts(pipeline, artifacts)
    print("Training finished successfully. Metrics:", artifacts["test_metrics"])

