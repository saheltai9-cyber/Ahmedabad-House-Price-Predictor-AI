"""
Inference and prediction service module for Ahmedabad House Price Predictor AI.
Loads the trained pipeline, validates input features, and provides formatted property valuations.
"""
import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any, Union, List, Optional, Tuple
import joblib
import pandas as pd
import numpy as np

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config import settings
else:
    from config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

def format_inr_rupees(amount_in_lakhs: float) -> str:
    """
    Converts amount in Lakhs to standard Indian comma formatted Rupee string.
    e.g., 48.5 Lakhs -> '₹ 48,50,000'
    """
    if pd.isna(amount_in_lakhs) or amount_in_lakhs < 0:
        return "₹ 0"
    rupees = int(round(amount_in_lakhs * 100000))
    s = str(rupees)
    if len(s) <= 3:
        return f"₹ {s}"
    last3 = s[-3:]
    other = s[:-3]
    res = ""
    while len(other) > 2:
        res = "," + other[-2:] + res
        other = other[:-2]
    res = other + res + "," + last3
    return f"₹ {res}"

def format_denomination(amount_in_lakhs: float) -> str:
    """
    Formats price into Lakhs or Crores representation.
    """
    if pd.isna(amount_in_lakhs) or amount_in_lakhs < 0:
        return "₹ 0.00 Lakhs"
    if amount_in_lakhs >= 100.0:
        cr_val = amount_in_lakhs / 100.0
        return f"₹ {cr_val:.2f} Crore{'s' if cr_val >= 2 else ''}"
    return f"₹ {amount_in_lakhs:.2f} Lakhs"

def calculate_emi(
    property_price_lakhs: float,
    interest_rate_pct: float = 8.5,
    tenure_years: int = 20,
    down_payment_pct: float = 20.0
) -> Dict[str, Any]:
    """
    Computes standard monthly home loan EMI, principal, and total interest for a property valuation.
    """
    if property_price_lakhs <= 0:
        return {"monthly_emi_rupees": "₹ 0", "loan_amount_rupees": "₹ 0", "total_interest_rupees": "₹ 0"}
    
    total_price = property_price_lakhs * 100000.0
    loan_principal = total_price * (1.0 - (down_payment_pct / 100.0))
    monthly_rate = (interest_rate_pct / 100.0) / 12.0
    num_months = tenure_years * 12

    if monthly_rate == 0:
        monthly_emi = loan_principal / num_months
    else:
        monthly_emi = (loan_principal * monthly_rate * ((1 + monthly_rate) ** num_months)) / (
            ((1 + monthly_rate) ** num_months) - 1
        )

    total_payment = monthly_emi * num_months
    total_interest = total_payment - loan_principal

    return {
        "monthly_emi": round(monthly_emi, 2),
        "monthly_emi_formatted": format_inr_rupees(monthly_emi / 100000.0),
        "loan_principal_formatted": format_inr_rupees(loan_principal / 100000.0),
        "total_interest_formatted": format_inr_rupees(total_interest / 100000.0),
        "down_payment_formatted": format_inr_rupees((total_price * (down_payment_pct / 100.0)) / 100000.0),
        "tenure_months": num_months
    }


class AhmedabadPricePredictor:
    """
    Predictor engine wrapping the trained Scikit-learn pipeline and metadata.
    """
    def __init__(self, model_path: Path = settings.MODEL_PATH, metadata_path: Path = settings.METADATA_PATH):
        self.model_path = Path(model_path)
        self.metadata_path = Path(metadata_path)
        self.pipeline = None
        self.metadata = {}
        self.load_artifacts()

    def load_artifacts(self) -> None:
        """
        Loads the joblib pipeline and metadata JSON.
        """
        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Model file not found at {self.model_path}. "
                "Please run train.py first to train and generate the model artifact."
            )
        
        logger.info(f"Loading trained pipeline from {self.model_path}...")
        self.pipeline = joblib.load(self.model_path)
        # Optimize regressor for fast real-time single-sample inference
        if hasattr(self.pipeline, "named_steps") and "regressor" in self.pipeline.named_steps:
            if hasattr(self.pipeline.named_steps["regressor"], "n_jobs"):
                self.pipeline.named_steps["regressor"].n_jobs = 1

        if self.metadata_path.exists():
            with open(self.metadata_path, "r", encoding="utf-8") as f:
                self.metadata = json.load(f)
        else:
            logger.warning(f"Metadata file not found at {self.metadata_path}. Using fallback values.")
            self.metadata = {}

    def get_supported_localities(self) -> List[str]:
        """
        Returns list of validated Ahmedabad localities from model metadata.
        """
        return self.metadata.get("supported_localities", ["Shela", "Bopal", "Satellite", "Gota", "Bodakdev", "Other"])

    def validate_inputs(self, property_data: Dict[str, Any]) -> Tuple[bool, Optional[str]]:
        """
        Validates user inputs against domain constraints before inference.
        """
        # Validate BHK
        bhk = property_data.get("bhk")
        if bhk is None or not (1 <= bhk <= 10):
            return False, "BHK must be an integer between 1 and 10."

        # Validate Area
        area = property_data.get("total_sqft")
        if area is None or area < 100 or area > 50000:
            return False, "Total area must be between 100 and 50,000 square feet."

        # Validate Locality
        locality = property_data.get("locality")
        if not locality or not isinstance(locality, str) or locality.strip() == "":
            return False, "Please select or provide a valid Ahmedabad locality."

        return True, None

    def predict(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generates real-time house price prediction and returns full valuation report.
        """
        is_valid, error_msg = self.validate_inputs(property_data)
        if not is_valid:
            raise ValueError(error_msg)

        # Build feature DataFrame matching pipeline expected schema
        input_row = {
            "total_sqft": float(property_data["total_sqft"]),
            "bhk": int(property_data["bhk"]),
            "locality": str(property_data.get("locality", "Other")).strip(),
            "type_area": str(property_data.get("type_area", "Super Area")),
            "status": str(property_data.get("status", "Ready to Move")),
            "furnishing": str(property_data.get("furnishing", "Unfurnished")),
            "transaction": str(property_data.get("transaction", "Resale")),
        }
        df_input = pd.DataFrame([input_row])

        # Inference
        raw_pred_lakhs = float(self.pipeline.predict(df_input)[0])
        pred_lakhs = max(1.0, round(raw_pred_lakhs, 2))  # Guard against negative outputs

        # Calculate empirical error range based on held-out test MAE
        test_mae = float(self.metadata.get("test_metrics", {}).get("mae_lakhs", 15.0))
        lower_bound_lakhs = max(1.0, round(pred_lakhs - test_mae, 2))
        upper_bound_lakhs = round(pred_lakhs + test_mae, 2)

        # Derived rate per sqft
        rate_per_sqft = (pred_lakhs * 100000.0) / input_row["total_sqft"]

        return {
            "predicted_price_lakhs": pred_lakhs,
            "formatted_rupees": format_inr_rupees(pred_lakhs),
            "formatted_denomination": format_denomination(pred_lakhs),
            "lower_bound_lakhs": lower_bound_lakhs,
            "upper_bound_lakhs": upper_bound_lakhs,
            "lower_bound_formatted": format_denomination(lower_bound_lakhs),
            "upper_bound_formatted": format_denomination(upper_bound_lakhs),
            "rate_per_sqft": round(rate_per_sqft, 2),
            "rate_per_sqft_formatted": f"₹ {int(round(rate_per_sqft)):,} / sq.ft",
            "model_name": self.metadata.get("best_model_name", "Extra Trees Regressor"),
            "test_mae_lakhs": test_mae,
            "r2_score": self.metadata.get("test_metrics", {}).get("r2_score", "N/A"),
            "inputs": input_row,
            "disclaimer": (
                "Notice: This prediction is an algorithmic statistical estimate based on historical "
                "Ahmedabad property listing records. It does not constitute an official bank or government appraisal."
            )
        }

if __name__ == "__main__":
    predictor = AhmedabadPricePredictor()
    sample = {
        "locality": "Shela",
        "bhk": 3,
        "total_sqft": 1500,
        "type_area": "Carpet Area",
        "status": "Ready to Move",
        "furnishing": "Semi-Furnished",
        "transaction": "Resale"
    }
    result = predictor.predict(sample)
    print("Sample Prediction Result:")
    print(json.dumps(result, indent=2))
