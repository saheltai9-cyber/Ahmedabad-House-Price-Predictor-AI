"""
Visualization and Exploratory Data Analysis module for Ahmedabad House Price Predictor AI.
Generates publication-quality charts saved to reports/figures/.
"""
import sys
import logging
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config import settings
else:
    from config import settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Set consistent professional styling
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
PRIMARY_COLOR = "#0B2545"    # Navy Blue
SECONDARY_COLOR = "#134074"  # Medium Blue
ACCENT_COLOR = "#8DA9C4"     # Soft Blue
LIGHT_BG = "#EEF4F8"

def plot_price_distribution(df: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> Path:
    """
    Plots the distribution of property prices in INR Lakhs with KDE and median line.
    """
    fig, ax = plt.subplots(figsize=(10, 5), dpi=200)
    sns.histplot(df["price_lakhs"], kde=True, color=PRIMARY_COLOR, bins=40, ax=ax, alpha=0.7)
    
    median_val = df["price_lakhs"].median()
    mean_val = df["price_lakhs"].mean()
    ax.axvline(median_val, color="#D90429", linestyle="--", linewidth=2, label=f"Median: ₹{median_val:.1f}L")
    ax.axvline(mean_val, color="#FFB703", linestyle=":", linewidth=2, label=f"Mean: ₹{mean_val:.1f}L")
    
    ax.set_title("House Price Distribution in Ahmedabad (INR Lakhs)", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Property Price (₹ in Lakhs)", fontsize=11)
    ax.set_ylabel("Number of Listings", fontsize=11)
    ax.legend(frameon=True)
    plt.tight_layout()
    
    save_path = output_dir / "price_distribution.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def plot_locality_price_distribution(df: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR, top_n: int = 15) -> Path:
    """
    Plots median property prices for top Ahmedabad localities.
    """
    # Filter out 'Other' for top locality comparison
    df_loc = df[df["locality"] != "Other"]
    top_localities = df_loc["locality"].value_counts().head(top_n).index
    df_top = df_loc[df_loc["locality"].isin(top_localities)]
    
    order = df_top.groupby("locality")["price_lakhs"].median().sort_values(ascending=False).index

    fig, ax = plt.subplots(figsize=(12, 7), dpi=200)
    sns.barplot(
        data=df_top,
        x="price_lakhs",
        y="locality",
        order=order,
        estimator=np.median,
        errorbar=None,
        palette="Blues_r",
        ax=ax
    )
    
    for p in ax.patches:
        width = p.get_width()
        ax.annotate(
            f"₹{width:.1f}L",
            (width + 2, p.get_y() + p.get_height() / 2),
            ha="left", va="center", fontsize=10, fontweight="bold", color="#111827"
        )
        
    ax.set_title(f"Median Property Price by Top {top_n} Ahmedabad Localities", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Median Price (₹ in Lakhs)", fontsize=11)
    ax.set_ylabel("Ahmedabad Locality", fontsize=11)
    plt.tight_layout()
    
    save_path = output_dir / "locality_price_distribution.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def plot_bhk_distribution(df: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> Path:
    """
    Plots BHK configuration counts and average price per BHK in Ahmedabad.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5), dpi=200)
    
    # 1. Frequency
    bhk_counts = df["bhk"].value_counts().sort_index()
    sns.barplot(x=bhk_counts.index, y=bhk_counts.values, ax=ax1, color=SECONDARY_COLOR)
    ax1.set_title("Listing Count by BHK Configuration", fontsize=12, fontweight="bold")
    ax1.set_xlabel("Number of Bedrooms (BHK)", fontsize=10)
    ax1.set_ylabel("Number of Listings", fontsize=10)
    for p in ax1.patches:
        ax1.annotate(f"{int(p.get_height()):,}", (p.get_x() + p.get_width() / 2, p.get_height() + 20), ha="center", fontsize=9)

    # 2. Average Price by BHK
    sns.barplot(data=df, x="bhk", y="price_lakhs", estimator=np.median, errorbar=None, ax=ax2, color="#0A9396")
    ax2.set_title("Median Price by BHK (₹ in Lakhs)", fontsize=12, fontweight="bold")
    ax2.set_xlabel("Number of Bedrooms (BHK)", fontsize=10)
    ax2.set_ylabel("Median Price (₹ in Lakhs)", fontsize=10)
    for p in ax2.patches:
        ax2.annotate(f"₹{p.get_height():.1f}L", (p.get_x() + p.get_width() / 2, p.get_height() + 5), ha="center", fontsize=9, fontweight="bold")

    plt.suptitle("BHK Analysis in Ahmedabad Real Estate Market", fontsize=14, fontweight="bold", y=1.02)
    plt.tight_layout()
    
    save_path = output_dir / "bhk_distribution.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def plot_area_vs_price(df: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> Path:
    """
    Plots property area (sqft) versus price (Lakhs) with trendline.
    """
    fig, ax = plt.subplots(figsize=(10, 6), dpi=200)
    sns.scatterplot(
        data=df,
        x="total_sqft",
        y="price_lakhs",
        hue="bhk",
        palette="viridis",
        alpha=0.6,
        s=35,
        ax=ax
    )
    
    # Regression trendline
    sns.regplot(
        data=df,
        x="total_sqft",
        y="price_lakhs",
        scatter=False,
        ax=ax,
        color="#D90429",
        line_kws={"linewidth": 2, "linestyle": "--", "label": "Market Trendline"}
    )
    
    ax.set_title("Property Area (Sq.Ft.) vs. Price (₹ in Lakhs) in Ahmedabad", fontsize=14, fontweight="bold", pad=12)
    ax.set_xlabel("Total Living Area (Square Feet)", fontsize=11)
    ax.set_ylabel("Property Price (₹ in Lakhs)", fontsize=11)
    ax.legend(title="BHK", frameon=True)
    plt.tight_layout()
    
    save_path = output_dir / "area_vs_price.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def plot_missing_values_analysis(df_raw: pd.DataFrame, df_clean: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> Path:
    """
    Visualizes missing values comparison before and after data cleaning.
    """
    raw_missing = df_raw.isnull().sum()
    raw_missing = raw_missing[raw_missing > 0].sort_values(ascending=False)
    
    fig, ax = plt.subplots(figsize=(10, 5), dpi=200)
    if len(raw_missing) > 0:
        sns.barplot(x=raw_missing.values, y=raw_missing.index, color="#E76F51", ax=ax)
        for p in ax.patches:
            val = int(p.get_width())
            pct = (val / len(df_raw)) * 100
            ax.annotate(f"{val} ({pct:.1f}%)", (val + 10, p.get_y() + p.get_height() / 2), ha="left", va="center", fontsize=9)
    else:
        ax.text(0.5, 0.5, "No missing values in raw dataset", ha="center", va="center", fontsize=12)

    ax.set_title("Missing Values in Scraped Ahmedabad Raw Dataset", fontsize=13, fontweight="bold", pad=12)
    ax.set_xlabel("Count of Missing Values", fontsize=11)
    ax.set_ylabel("Raw Dataset Columns", fontsize=11)
    plt.tight_layout()
    
    save_path = output_dir / "missing_values_analysis.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def plot_correlation_heatmap(df: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> Path:
    """
    Computes and plots correlation matrix across numerical variables.
    """
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    corr = df[numeric_cols].corr()

    fig, ax = plt.subplots(figsize=(7, 5), dpi=200)
    sns.heatmap(corr, annot=True, cmap="Blues", fmt=".2f", linewidths=0.8, cbar=True, ax=ax, square=True)
    ax.set_title("Correlation Heatmap (Numerical Features & Target)", fontsize=13, fontweight="bold", pad=12)
    plt.tight_layout()
    
    save_path = output_dir / "correlation_heatmap.png"
    plt.savefig(save_path)
    plt.close()
    logger.info(f"Saved: {save_path}")
    return save_path

def generate_all_eda_figures(df_raw: pd.DataFrame, df_clean: pd.DataFrame, output_dir: Path = settings.FIGURES_DIR) -> None:
    """
    Generates and saves the complete set of required EDA figures.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Generating EDA figures into {output_dir}...")

    plot_price_distribution(df_clean, output_dir)
    plot_locality_price_distribution(df_clean, output_dir)
    plot_bhk_distribution(df_clean, output_dir)
    plot_area_vs_price(df_clean, output_dir)
    plot_missing_values_analysis(df_raw, df_clean, output_dir)
    plot_correlation_heatmap(df_clean, output_dir)
    logger.info("All EDA figures generated successfully.")

if __name__ == "__main__":
    from src.data_loader import load_raw_dataset
    from src.preprocessing import clean_dataset
    settings.init_directories()
    df_raw = load_raw_dataset()
    df_clean, _ = clean_dataset(df_raw)
    generate_all_eda_figures(df_raw, df_clean)
    print("Visualizations created successfully.")

