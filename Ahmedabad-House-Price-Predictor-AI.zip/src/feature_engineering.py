"""
Feature engineering and transformation pipeline for Ahmedabad House Price Predictor AI.
Defines Scikit-learn ColumnTransformer for numerical scaling and categorical one-hot encoding.
"""
import sys
from pathlib import Path
from typing import Tuple, List
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from config import settings
else:
    from config import settings

def build_preprocessor(
    numerical_features: List[str] = settings.NUMERICAL_FEATURES,
    categorical_features: List[str] = settings.CATEGORICAL_FEATURES
) -> ColumnTransformer:
    """
    Constructs a robust Scikit-learn ColumnTransformer for tabular preprocessing:
    - Numerical: median imputation followed by standard scaling.
    - Categorical: most-frequent imputation followed by handle_unknown='ignore' One-Hot Encoding.
    """
    numerical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numerical_pipeline, numerical_features),
            ("cat", categorical_pipeline, categorical_features),
        ],
        remainder="drop"
    )

    return preprocessor

def prepare_features_and_target(
    df: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Separates independent feature matrix X from dependent target vector y.
    Strictly excludes target-derived leakage columns.
    """
    for col in settings.LEAKAGE_COLUMNS:
        if col in df.columns and col != settings.TARGET_FEATURE:
            df = df.drop(columns=[col])

    required_features = settings.NUMERICAL_FEATURES + settings.CATEGORICAL_FEATURES
    for feat in required_features:
        if feat not in df.columns:
            raise KeyError(f"Required feature '{feat}' not found in DataFrame columns: {df.columns.tolist()}")

    if settings.TARGET_FEATURE not in df.columns:
        raise KeyError(f"Target column '{settings.TARGET_FEATURE}' not found in DataFrame.")

    X = df[required_features].copy()
    y = df[settings.TARGET_FEATURE].copy()

    return X, y

if __name__ == "__main__":
    preprocessor = build_preprocessor()
    print("Preprocessor initialized successfully:")
    print(preprocessor)

