"""
Ahmedabad House Price Predictor AI source package.
"""

