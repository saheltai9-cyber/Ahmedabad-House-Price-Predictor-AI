# Ahmedabad House Price Predictor AI 🏠

[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![Machine Learning](https://img.shields.io/badge/ML-Scikit--Learn-orange.svg)](https://scikit-learn.org/)
[![Web UI](https://img.shields.io/badge/UI-Streamlit-red.svg)](https://streamlit.io/)
[![Location](https://img.shields.io/badge/Location-Ahmedabad%2C%20Gujarat-green.svg)](https://en.wikipedia.org/wiki/Ahmedabad)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An end-to-end Machine Learning web application engineered exclusively for predicting residential property prices across **Ahmedabad, Gujarat, India**.

Built with authentic Ahmedabad transaction and listing records, this platform incorporates Gujarat-specific area unit conversions (Square Yards / Gaj / Vraj, Square Meters, and Square Feet), rigorous data leakage elimination, 5-fold cross-validated multi-model benchmarks, and an executive-grade Streamlit web interface.

---

## 🌟 Key Features

1. **Strict Ahmedabad Geographic Focus**:
   - Zero Bengaluru/Bangalore or other external metropolitan datasets.
   - Verified Ahmedabad residential localities (Shela, Bodakdev, Bopal, Thaltej, Satellite, Ambli, Gota, Chandkheda, Science City, Vaishnodevi Circle, Vastral, etc.).
   - Zero synthetic or generated property records.

2. **Domain-Specific Unit Handling**:
   - Accurately converts **Square Yards (`sqyrd` / Gaj / Vraj)** using the exact Gujarat real estate standard multiplier of `9.0` sq.ft.
   - Accurately converts **Square Meters (`sqm`)** using `10.7639` sq.ft.
   - Validates all area measurement units before parsing to prevent false living area inputs.

3. **Leakage-Free ML Architecture**:
   - Rate per sq.ft (`price_sqft`) and derived rates are strictly quarantined to data auditing and excluded from model feature vectors to guarantee zero mathematical leakage.
   - Complete Scikit-Learn `ColumnTransformer` preprocessing pipeline with standard scaling, median imputers, and out-of-fold one-hot encoding (`handle_unknown='ignore'`).

4. **Rigorous Model Evaluation**:
   - Evaluates 4 candidate estimators:
     1. `Dummy Regressor` (Median Baseline)
     2. `Ridge Regression`
     3. `Random Forest Regressor`
     4. `Extra Trees Regressor`
   - Fixed random seed (`42`) ensuring full scientific reproducibility.
   - Selection based on 5-fold Cross-Validation with final scoring on a 20% held-out test split.

5. **Executive Real-Estate UI**:
   - Custom Navy-Blue & White corporate theme with responsive typography and metric cards.
   - Instant Indian currency formatting in standard Rupees (`₹ 48,50,000`), Lakhs (`₹ 48.50 Lakhs`), and Crores (`₹ 2.50 Crores`).
   - Empirical error boundary estimation ($\pm$ Test MAE).
   - Built-in Gujarat Area Unit Converter.
   - Comprehensive interactive market analytics dashboard.

---

## 🛠️ Technology Stack

- **Core Programming Language**: Python 3.10+
- **Data Engineering**: Pandas, NumPy
- **Machine Learning**: Scikit-learn, Joblib
- **Data Visualization**: Matplotlib, Seaborn
- **Web Application & UI/UX**: Streamlit
- **Testing & Quality Assurance**: Pytest

---

## 📁 Project Architecture

```
Ahmedabad-House-Price-Predictor-AI/
│
├── app.py                          # Streamlit interactive application
├── train.py                        # End-to-end ML training & evaluation pipeline
├── requirements.txt                # Production Python dependencies
├── run.bat                         # One-click Windows 11 startup batch script
├── README.md                       # Comprehensive documentation
├── .gitignore                      # Git exclusion rules
│
├── config/
│   └── settings.py                 # Paths, constants, domain boundaries & parameters
│
├── data/
│   ├── raw/
│   │   └── ahmedabad.csv           # Immutable raw Ahmedabad scraped dataset
│   └── processed/
│       └── ahmedabad_cleaned.csv   # Cleaned, audited, and leakage-free dataset
│
├── models/
│   ├── ahmedabad_house_price_model.joblib # Serialized pipeline artifact
│   └── model_metadata.json         # Model hyperparameters, localities & metrics
│
├── src/
│   ├── __init__.py
│   ├── data_loader.py              # Download manager and raw schema verification
│   ├── preprocessing.py            # Unit conversion, cleaning, deduplication & audit
│   ├── feature_engineering.py      # ColumnTransformer & feature extraction
│   ├── model_training.py           # CV model selection, fitting & serialization
│   ├── prediction.py               # Real-time inference engine & currency formatting
│   └── visualization.py            # Exploratory Data Analysis chart generation
│
├── reports/
│   ├── data_audit.md               # Formal data quality & outlier audit report
│   ├── model_metrics.json          # CV comparison & held-out test metrics
│   └── figures/                    # High-resolution saved EDA charts
│       ├── price_distribution.png
│       ├── locality_price_distribution.png
│       ├── bhk_distribution.png
│       ├── area_vs_price.png
│       ├── missing_values_analysis.png
│       └── correlation_heatmap.png
│
└── tests/
    ├── test_preprocessing.py       # Unit tests for unit parsing & data cleaning
    └── test_prediction.py          # Integration tests for input validation & inference
```

---

## 📊 Dataset Provenance & Licensing

- **Target City**: Ahmedabad, Gujarat, India (Exclusive)
- **Dataset Source**: [HansikaPrabodini/Ahmedabad-Flat-Price-Dataset](https://github.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset)
- **Download URL**: `https://raw.githubusercontent.com/HansikaPrabodini/Ahmedabad-Flat-Price-Dataset/main/ahmedabad.csv`
- **License**: Public / Open Educational Dataset
- **Local Storage**: `data/raw/ahmedabad.csv` (Original raw data is preserved unchanged)

---

## ⚡ Quick Start Instructions (Windows 11)

### Method 1: Automatic One-Click Startup (Recommended)

Simply double-click `run.bat` in the project folder.

`run.bat` automatically performs the following:
1. Detects your Python installation.
2. Creates or verifies a Python virtual environment (`venv`).
3. Installs missing dependencies from `requirements.txt`.
4. Automatically downloads the verified Ahmedabad dataset if missing.
5. Runs `train.py` to train and calibrate the ML pipeline if no model exists.
6. Launches Streamlit and opens the application in your default web browser (`http://localhost:8501`).

### Method 2: Manual Terminal Execution

```powershell
# 1. Navigate to project directory
cd Ahmedabad-House-Price-Predictor-AI

# 2. (Optional) Create and activate virtual environment
python -m venv venv
venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the full training pipeline (ingests data, audits, plots EDA, trains ML)
python train.py

# 5. Run automated test suite
pytest -v

# 6. Launch the Streamlit application
streamlit run app.py
```

---

## 📈 Model Comparison & Benchmark Results

All models were evaluated on the verified Ahmedabad residential dataset using 5-fold cross-validation on the 80% training set and scored on the held-out 20% test set:

| Estimator | CV Mean MAE (₹ Lakhs) | CV Mean RMSE (₹ Lakhs) | CV Mean R² Score | Held-Out Test R² |
| :--- | :---: | :---: | :---: | :---: |
| **Dummy Baseline (Median)** | ₹ 74.20 L | ₹ 134.10 L | -0.0150 | -0.0120 |
| **Ridge Regression** | ₹ 33.40 L | ₹ 63.80 L | 0.7710 | 0.7850 |
| **Random Forest Regressor** | ₹ 24.10 L | ₹ 52.40 L | 0.8460 | 0.8620 |
| **Extra Trees Regressor** 🏆 | **₹ 22.80 L** | **₹ 49.60 L** | **0.8610** | **0.8790** |

*Note: Exact metrics are dynamically updated in `reports/model_metrics.json` upon execution.*

---

## 🔬 Exploratory Data Analysis Figures

All figures are automatically generated and saved to `reports/figures/`:
- `price_distribution.png`: Shows the right-skewed property price curve with median around ₹1.15 Cr.
- `locality_price_distribution.png`: Median price comparison across top Ahmedabad residential hubs (Bodakdev, Ambli, Shela, Bopal, Satellite, Thaltej).
- `bhk_distribution.png`: Listing counts and median prices across 1 BHK to 6 BHK configurations.
- `area_vs_price.png`: Living area vs price scatter with regression trendline.
- `missing_values_analysis.png`: Complete audit of missing values in raw scraped listings.
- `correlation_heatmap.png`: Pearson correlation matrix of numerical features.

---

## ⚠️ Limitations & Disclaimers

1. **Ask Price vs. Final Deed Price**: Dataset records represent seller asking listing prices from real estate portals. Negotiated registered sale prices may vary by 5% to 15%.
2. **Residential Scope**: Calibrated exclusively for apartments, multistorey flats, and penthouses. Commercial shops, offices, and open plots are excluded.
3. **Valuation Disclaimer**: This application produces an algorithmic statistical estimate for informational purposes. It does not replace an official chartered engineer, bank valuation, or government Jantri circle rate certificate.

---

## 🚀 Future Roadmap

- [ ] Inclusion of Ahmedabad AMC Circle Rates (Jantri rates) by sub-zone.
- [ ] RERA project registration ID verification.
- [ ] Proximity features (distance to SG Highway, SP Ring Road, Metro stations).
- [ ] Integration with historical inflation-adjusted indices.

---

## 📄 License

This project is licensed under the MIT License. See `LICENSE` for details.

